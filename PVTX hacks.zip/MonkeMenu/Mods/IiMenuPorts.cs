// AUTO-GENERATED from ii's Stupid Menu — wired to real client-side behavior where possible.
// Fun category omitted on purpose.
using System.Collections.Generic;
using GorillaLocomotion;
using UnityEngine;
using Object = UnityEngine.Object;

namespace MonkeMenu.Mods;

using MonkeMenu.Core;


/// <summary>Shared client-side implementations used by ii port mods.</summary>
public static class IiRt
{
    public static void TagAll()
    {
        if (!H.Ready) return;
        foreach (var r in Adv.OtherRigs()) Adv.TryTag(r);
    }

    public static void TagNear(float range)
    {
        if (!H.Ready) return;
        Vector3 me = H.Head.position;
        foreach (var r in Adv.OtherRigs())
            if (Vector3.Distance(me, Adv.RigHead(r)) < range) Adv.TryTag(r);
    }

    public static void TagAim()
    {
        if (!H.Ready || !H.RTrig) return;
        Vector3 o = H.RHand.position, d = H.Point(false);
        Component best = null; float bestS = 999f;
        foreach (var r in Adv.OtherRigs())
        {
            Vector3 h = Adv.RigHead(r);
            float dist = Vector3.Distance(o, h);
            if (dist > 60f) continue;
            float ang = Vector3.Angle(d, h - o);
            if (ang > 14f) continue;
            float s = ang + dist * 0.02f;
            if (s < bestS) { bestS = s; best = r; }
        }
        if (best != null) Adv.TryTag(best);
    }

    public static void SetLocalVisible(bool on)
    {
        if (!H.Ready) return;
        var local = Adv.LocalRig();
        if (local != null) Adv.SetRenderers(local, on);
        else
        {
            Adv.SetRenderers(GTPlayer.Instance, on);
            if (GorillaTagger.Instance != null) Adv.SetRenderers(GorillaTagger.Instance, on);
        }
    }

    public static void Fly(float speed)
    {
        if (!H.Ready) return;
        H.Rb.velocity = H.Look.forward * speed;
    }

    public static void Speed(float mult)
    {
        if (!H.Ready) return;
        Vector3 v = H.Rb.velocity;
        Vector3 flat = new Vector3(v.x, 0f, v.z);
        if (flat.magnitude > 0.2f)
            H.Rb.velocity = flat.normalized * (flat.magnitude * mult) + Vector3.up * v.y;
    }

    static readonly List<Collider> noclipOff = new();
    public static void Noclip(bool on)
    {
        if (!H.Ready) return;
        if (!on)
        {
            foreach (var c in noclipOff) if (c != null) c.enabled = true;
            noclipOff.Clear();
            return;
        }
        if (noclipOff.Count > 0) return;
        Transform self = GTPlayer.Instance.transform.root;
        foreach (var c in Object.FindObjectsByType<Collider>(FindObjectsSortMode.None))
        {
            if (c == null || c.isTrigger || !c.enabled) continue;
            if (c.transform.IsChildOf(self)) continue;
            if (!(c is MeshCollider || c is BoxCollider)) continue;
            c.enabled = false;
            noclipOff.Add(c);
        }
    }

    static readonly GameObject[] plats = new GameObject[2];
    public static void Platforms(bool grip)
    {
        if (!H.Ready) return;
        for (int i = 0; i < 2; i++)
        {
            bool left = i == 0;
            bool hold = grip ? H.Grip(left) : H.Trigger(left);
            if (hold)
            {
                if (plats[i] == null)
                {
                    plats[i] = H.Prim(PrimitiveType.Cube, new Vector3(0.4f, 0.06f, 0.4f), new Color(0.6f, 0.3f, 1f));
                    plats[i].AddComponent<KeepSolid>();
                }
                var hand = H.Hand(left);
                plats[i].transform.position = hand.position + Vector3.down * 0.05f;
                plats[i].transform.rotation = Quaternion.Euler(0f, hand.eulerAngles.y, 0f);
            }
            else if (plats[i] != null)
            {
                Object.Destroy(plats[i]);
                plats[i] = null;
            }
        }
    }

    public static void ClearPlatforms()
    {
        for (int i = 0; i < 2; i++)
        {
            if (plats[i] != null) Object.Destroy(plats[i]);
            plats[i] = null;
        }
    }

    static readonly List<LineRenderer> esp = new();
    public static void EspTick()
    {
        if (!H.Ready) return;
        var rigs = Adv.OtherRigs();
        while (esp.Count < rigs.Count)
            esp.Add(H.MakeLine("IiESP", Color.red, 0.01f));
        while (esp.Count > rigs.Count)
        {
            int i = esp.Count - 1;
            if (esp[i] != null) Object.Destroy(esp[i].gameObject);
            esp.RemoveAt(i);
        }
        Vector3 from = H.Head.position;
        for (int i = 0; i < rigs.Count; i++)
        {
            Vector3 to = Adv.RigHead(rigs[i]);
            esp[i].SetPosition(0, from);
            esp[i].SetPosition(1, to);
            float d = Vector3.Distance(from, to);
            esp[i].startColor = esp[i].endColor = Color.Lerp(Color.green, Color.red, Mathf.Clamp01(d / 40f));
        }
    }

    public static void EspOff()
    {
        foreach (var l in esp) if (l != null) Object.Destroy(l.gameObject);
        esp.Clear();
    }

    public static void LongArms(float m)
    {
        if (!H.Ready || m <= 1.01f) return;
        Vector3 head = H.Head.position;
        Stretch(H.LHand, head, m);
        Stretch(H.RHand, head, m);
    }
    static void Stretch(Transform hand, Vector3 head, float m)
    {
        if (hand == null) return;
        Vector3 o = hand.position - head;
        if (o.sqrMagnitude < 0.0001f) return;
        hand.position = head + o * m;
    }

    public static void PullGun()
    {
        if (!H.Ready || !H.RGrip || !H.RTrig) return;
        Vector3 o = H.RHand.position, d = H.Point(false);
        Component best = null; float bestS = 999f;
        foreach (var r in Adv.OtherRigs())
        {
            Vector3 h = Adv.RigHead(r);
            float dist = Vector3.Distance(o, h);
            if (dist > 60f) continue;
            float ang = Vector3.Angle(d, h - o);
            if (ang > 14f) continue;
            float s = ang + dist * 0.02f;
            if (s < bestS) { bestS = s; best = r; }
        }
        if (best != null)
            best.transform.root.position += (H.Head.position - Adv.RigHead(best)).normalized * 8f * Time.deltaTime;
    }

    public static void ShootPrim()
    {
        if (!H.Ready || !H.RTrig) return;
        var c = H.Prim(PrimitiveType.Sphere, Vector3.one * 0.15f, H.Rainbow(2f));
        c.transform.position = H.RHand.position + H.Point(false) * 0.25f;
        var rb = c.AddComponent<Rigidbody>();
        rb.velocity = H.Point(false) * 18f;
        H.Track(c, 6f);
    }

    public static void WallWalk()
    {
        if (!H.Ready) return;
        for (int i = 0; i < 2; i++)
        {
            bool left = i == 0;
            if (!H.Grip(left)) continue;
            if (Physics.Raycast(H.Hand(left).position, H.Palm(left), out RaycastHit hit, 0.45f))
            {
                H.Rb.AddForce(-hit.normal * 20f, ForceMode.Acceleration);
                H.Rb.AddForce(Vector3.up * 9.81f, ForceMode.Acceleration);
            }
        }
    }
}

// ========== Visual ==========
[ModCategory(Cat.Visual)]
[ModInfo("Morning Time", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_MorningTime : MenuMod
{
    public override void Update() { RenderSettings.ambientLight = new Color(0.95f,0.92f,0.85f); RenderSettings.ambientIntensity = 1.1f; }
}
[ModCategory(Cat.Visual)]
[ModInfo("Day Time", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DayTime : MenuMod
{
    public override void Update() { RenderSettings.ambientLight = new Color(0.95f,0.92f,0.85f); RenderSettings.ambientIntensity = 1.1f; }
}
[ModCategory(Cat.Visual)]
[ModInfo("Evening Time", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_EveningTime : MenuMod
{
    public override void Update() { RenderSettings.ambientLight = new Color(0.9f,0.45f,0.2f); RenderSettings.ambientIntensity = 0.7f; }
}
[ModCategory(Cat.Visual)]
[ModInfo("Night Time", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_NightTime : MenuMod
{
    public override void Update() { RenderSettings.ambientLight = new Color(0.05f,0.05f,0.12f); RenderSettings.ambientIntensity = 0.35f; }
}
[ModCategory(Cat.Visual)]
[ModInfo("Fullbright", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_Fullbright : MenuMod
{
    public override void Update() { RenderSettings.ambientLight = Color.white; RenderSettings.ambientIntensity = 1.4f; RenderSettings.fog = false; }
}
[ModCategory(Cat.Visual)]
[ModInfo("Remove Blindfold", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_RemoveBlindfold : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Core ESP", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_CoreESP : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Critter ESP", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_CritterESP : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Creature ESP", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_CreatureESP : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Enemy ESP", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_EnemyESP : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Resource ESP", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ResourceESP : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Enable Snow", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_EnableSnow : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Rainy Weather", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_RainyWeather : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Clear Weather", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ClearWeather : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Disable Fog", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DisableFog : MenuMod
{
    public override void Update() { RenderSettings.fog = false; }
}
[ModCategory(Cat.Visual)]
[ModInfo("Enable Fog", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_EnableFog : MenuMod
{
    public override void Update() { RenderSettings.fog = true; }
}
[ModCategory(Cat.Visual)]
[ModInfo("Disable Ambience", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DisableAmbience : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Custom Skybox Color", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_CustomSkyboxColor : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Draw Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DrawGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Gamesense Ring", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GamesenseRing : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Velocity Label", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_VelocityLabel : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Nearby Label", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_NearbyLabel : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Last Label", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_LastLabel : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Time Label", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_TimeLabel : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("FPS Overlay", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FPSOverlay : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Ping Overlay", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PingOverlay : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Time Overlay", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_TimeOverlay : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Playtime Overlay", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PlaytimeOverlay : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Room Information Overlay", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_RoomInformationOverlay : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Extra Room Info Overlay", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ExtraRoomInfoOverlay : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Networking Overlay", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_NetworkingOverlay : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Clipboard Overlay", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ClipboardOverlay : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Velocity Overlay", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_VelocityOverlay : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Nearby Overlay", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_NearbyOverlay : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Info Overlay Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_InfoOverlayGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Debug HUD", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DebugHUD : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Info Watch", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_InfoWatch : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Leaderboard Info", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_LeaderboardInfo : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("FPS Boost", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FPSBoost : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Freeze In Background", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FreezeInBackground : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Fake Unban Self", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FakeUnbanSelf : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Jump Predictions", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_JumpPredictions : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Hitbox Predictions", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_HitboxPredictions : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Paintbrawl Trajectories", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PaintbrawlTrajectories : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Audio Visualizer", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AudioVisualizer : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Show Server Position", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ShowServerPosition : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Show Scheduled Objects", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ShowScheduledObjects : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Visualize Network Triggers", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_VisualizeNetworkTriggers : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Visualize Wind Barriers", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_VisualizeWindBarriers : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Visualize Map Triggers", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_VisualizeMapTriggers : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Name Tags", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_NameTags : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Velocity Name Tags", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_VelocityNameTags : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("FPS Name Tags", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FPSNameTags : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("ID Name Tags", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_IDNameTags : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Platform Name Tags", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PlatformNameTags : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("k-ID Name Tags", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_kIDNameTags : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Subscriber Name Tags", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SubscriberNameTags : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Creation Date Name Tags", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_CreationDateNameTags : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Ping Name Tags", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PingNameTags : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Turn Name Tags", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_TurnNameTags : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Tagged Name Tags", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_TaggedNameTags : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Mod Name Tags", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ModNameTags : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Cosmetic Name Tags", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_CosmeticNameTags : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Verified Name Tags", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_VerifiedNameTags : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Lag Name Tags", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_LagNameTags : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Compact Name Tags", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_CompactNameTags : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Minecraft Name Tags", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_MinecraftNameTags : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Casting Name Tags", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_CastingNameTags : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Fix Rig Colors", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FixRigColors : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Disable Rig Lerping", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DisableRigLerping : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Better Rig Lerping", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BetterRigLerping : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Remove Leaves", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_RemoveLeaves : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Streamer Remove Leaves", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_StreamerRemoveLeaves : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Remove Cosmetics", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_RemoveCosmetics : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("X-Ray [T]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_XRayT : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Cosmetic ESP", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_CosmeticESP : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Voice Indicators", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_VoiceIndicators : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Voice ESP", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_VoiceESP : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Platform Indicators", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PlatformIndicators : MenuMod
{
    public override string BindHint => "Grip";
    public override void OnDisable() => IiRt.ClearPlatforms();
    public override void Update() { if (Enabled) IiRt.Platforms(true); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Platform ESP", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PlatformESP : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("No Limb Mode", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_NoLimbMode : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Casual Tracers", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_CasualTracers : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Infection Tracers", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_InfectionTracers : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Hunt Tracers", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_HuntTracers : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Automatic Tracers", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutomaticTracers : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Nearest Tracer", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_NearestTracer : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Casual Box ESP", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_CasualBoxESP : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Infection Box ESP", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_InfectionBoxESP : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Hunt Box ESP", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_HuntBoxESP : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Automatic Box ESP", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutomaticBoxESP : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Casual Hollow Box ESP", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_CasualHollowBoxESP : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Infection Hollow Box ESP", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_InfectionHollowBoxESP : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Hunt Hollow Box ESP", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_HuntHollowBoxESP : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Automatic Hollow Box ESP", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutomaticHollowBoxESP : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Casual Breadcrumbs", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_CasualBreadcrumbs : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Infection Breadcrumbs", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_InfectionBreadcrumbs : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Hunt Breadcrumbs", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_HuntBreadcrumbs : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Automatic Breadcrumbs", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutomaticBreadcrumbs : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Casual Bone ESP", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_CasualBoneESP : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Infection Bone ESP", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_InfectionBoneESP : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Hunt Bone ESP", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_HuntBoneESP : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Automatic Bone ESP", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutomaticBoneESP : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Casual Skeleton ESP", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_CasualSkeletonESP : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Infection Skeleton ESP", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_InfectionSkeletonESP : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Hunt Skeleton ESP", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_HuntSkeletonESP : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Automatic Skeleton ESP", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutomaticSkeletonESP : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Casual Wireframe ESP", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_CasualWireframeESP : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Infection Wireframe ESP", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_InfectionWireframeESP : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Hunt Wireframe ESP", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_HuntWireframeESP : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Automatic Wireframe ESP", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutomaticWireframeESP : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Chams", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_Chams : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Casual Chams", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_CasualChams : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Infection Chams", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_InfectionChams : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Hunt Chams", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_HuntChams : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Automatic Chams", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutomaticChams : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Casual Beacons", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_CasualBeacons : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Infection Beacons", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_InfectionBeacons : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Hunt Beacons", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_HuntBeacons : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Automatic Beacons", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutomaticBeacons : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Casual Distance ESP", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_CasualDistanceESP : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Infection Distance ESP", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_InfectionDistanceESP : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Hunt Distance ESP", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_HuntDistanceESP : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Automatic Distance ESP", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutomaticDistanceESP : MenuMod
{
    public override void OnDisable() => IiRt.EspOff();
    public override void Update() { if (Enabled) IiRt.EspTick(); }
}
[ModCategory(Cat.Visual)]
[ModInfo("Show Pointers", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ShowPointers : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Info Watch Menu Name", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_InfoWatchMenuName : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Info Watch FPS", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_InfoWatchFPS : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Info Watch Time", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_InfoWatchTime : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Info Watch Clipboard", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_InfoWatchClipboard : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Visual)]
[ModInfo("Info Watch Code", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_InfoWatchCode : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
// ========== Experimental ==========
[ModCategory(Cat.Experimental)]
[ModInfo("Safe Restart Game", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SafeRestartGame : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Experimental)]
[ModInfo("Fix Broken Buttons", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FixBrokenButtons : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Experimental)]
[ModInfo("Get Sound Data", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GetSoundData : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Experimental)]
[ModInfo("Get Cosmetic Data", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GetCosmeticData : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Experimental)]
[ModInfo("Get Decryptable Cosmetic Data", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GetDecryptableCosmeticData : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Experimental)]
[ModInfo("Get RPC Data", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GetRPCData : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Experimental)]
[ModInfo("Blank Page", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BlankPage : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Experimental)]
[ModInfo("Copy Custom Gamemode Script", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_CopyCustomGamemodeScript : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Experimental)]
[ModInfo("Copy Custom Map ID", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_CopyCustomMapID : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Experimental)]
[ModInfo("Better FPS Boost", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BetterFPSBoost : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Experimental)]
[ModInfo("Replay Tutorial", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ReplayTutorial : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Experimental)]
[ModInfo("Disorganize Menu", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DisorganizeMenu : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
// ========== Detected ==========
[ModCategory(Cat.Detected)]
[ModInfo("Achievements", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_Achievements : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Credits", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_Credits : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Auto Set Master Client", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedAutoSetMasterClient : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Set Master Client Self", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedSetMasterClientSelf : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Set Master Client Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedSetMasterClientGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Set Master Client All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedSetMasterClientAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Set Master Client Aura", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedSetMasterClientAura : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Set Master Client On Touch", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedSetMasterClientOnTouch : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Lag Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedLagGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Lag All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedLagAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Lag Aura", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedLagAura : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Lag On Touch", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedLagOnTouch : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Crash Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedCrashGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Crash All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedCrashAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Crash Aura", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedCrashAura : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Crash On Touch", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedCrashOnTouch : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Crash When Touched", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedCrashWhenTouched : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Mute Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedMuteGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Mute All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedMuteAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Mute Aura", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedMuteAura : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Mute On Touch", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedMuteOnTouch : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Ghost Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedGhostGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Ghost All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedGhostAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Ghost Aura", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedGhostAura : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Ghost On Touch", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedGhostOnTouch : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Unghost Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedUnghostGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Unghost All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedUnghostAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Unghost Aura", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedUnghostAura : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Unghost On Touch", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedUnghostOnTouch : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Spam Ghost Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedSpamGhostGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Spam Ghost All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedSpamGhostAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Spam Ghost Aura", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedSpamGhostAura : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Spam Ghost On Touch", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedSpamGhostOnTouch : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Leaderboard Ghost", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_LeaderboardGhost : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Leaderboard Mute", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_LeaderboardMute : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Isolate Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedIsolateGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Isolate All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedIsolateAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Isolate Aura", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedIsolateAura : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Isolate On Touch", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedIsolateOnTouch : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Change Name Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedChangeNameGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Change Name All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedChangeNameAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Change Name Aura", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedChangeNameAura : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Change Name On Touch", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedChangeNameOnTouch : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Ban Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedBanGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Ban All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedBanAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Ban Aura", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedBanAura : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Detected Ban On Touch", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DetectedBanOnTouch : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Bypass Mod Checkers Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BypassModCheckersGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Bypass Mod Checkers All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BypassModCheckersAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Bypass Mod Checkers Aura", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BypassModCheckersAura : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Bypass Mod Checkers On Touch", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BypassModCheckersOnTouch : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Break Mod Checkers Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BreakModCheckersGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Break Mod Checkers All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BreakModCheckersAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Break Mod Checkers Aura", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BreakModCheckersAura : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Break Mod Checkers On Touch", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BreakModCheckersOnTouch : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Gamemode Include Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GamemodeIncludeGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Gamemode Include All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GamemodeIncludeAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Gamemode Include Aura", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GamemodeIncludeAura : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Gamemode Include On Touch", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GamemodeIncludeOnTouch : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Gamemode Exclude Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GamemodeExcludeGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Gamemode Exclude All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GamemodeExcludeAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Gamemode Exclude Aura", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GamemodeExcludeAura : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Gamemode Exclude On Touch", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GamemodeExcludeOnTouch : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Break Network Triggers", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BreakNetworkTriggers : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Kick Network Triggers", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_KickNetworkTriggers : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Spaz Gamemode", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SpazGamemode : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Break Gamemode", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BreakGamemode : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Change Gamemode to None", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ChangeGamemodetoNone : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Change Gamemode to Count", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ChangeGamemodetoCount : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Change Gamemode to Casual", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ChangeGamemodetoCasual : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Change Gamemode to Infection", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ChangeGamemodetoInfection : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Change Gamemode to Competitive Infection", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ChangeGamemodetoCompetitiveInfection : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Change Gamemode to Super Infection", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ChangeGamemodetoSuperInfection : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Change Gamemode to Super Casual", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ChangeGamemodetoSuperCasual : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Change Gamemode to Hunt", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ChangeGamemodetoHunt : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Change Gamemode to Paintbrawl", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ChangeGamemodetoPaintbrawl : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Change Gamemode to Ambush", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ChangeGamemodetoAmbush : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Change Gamemode to Ghost Tag", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ChangeGamemodetoGhostTag : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Change Gamemode to Guardian", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ChangeGamemodetoGuardian : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Change Gamemode to Freeze Tag", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ChangeGamemodetoFreezeTag : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Change Gamemode to Prop Hunt", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ChangeGamemodetoPropHunt : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Detected)]
[ModInfo("Change Gamemode to Custom", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ChangeGamemodetoCustom : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
// ========== Room ==========
[ModCategory(Cat.Room)]
[ModInfo("iiServers", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_iiServers : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("20 Player Rooms", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_M20PlayerRooms : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("crTime", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_crTime : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Disconnect", "ii port (client)", ButtonType.Fixed, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_Disconnect : MenuMod
{
    public override void Pressed() { Net.Disconnect(); }
}
[ModCategory(Cat.Room)]
[ModInfo("Reconnect", "ii port (client)", ButtonType.Fixed, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_Reconnect : MenuMod
{
    public override void Pressed() { Net.Disconnect(); }
}
[ModCategory(Cat.Room)]
[ModInfo("Cancel Reconnect", "ii port (client)", ButtonType.Fixed, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_CancelReconnect : MenuMod
{
    public override void Pressed() { Net.Disconnect(); }
}
[ModCategory(Cat.Room)]
[ModInfo("Fix My Map", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FixMyMap : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Dump World State", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DumpWorldState : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Join Last Room", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_JoinLastRoom : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Join Random", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_JoinRandom : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Create Public", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_CreatePublic : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Create Private", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_CreatePrivate : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Fast Disconnect", "ii port (client)", ButtonType.Fixed, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FastDisconnect : MenuMod
{
    public override void Pressed() { Net.Disconnect(); }
}
[ModCategory(Cat.Room)]
[ModInfo("Join Menu Room", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_JoinMenuRoom : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Bypass Join Room Type", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BypassJoinRoomType : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Auto Join Room", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoJoinRoom : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Auto Join Room \"TJA\"", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoJoinRoomTJA : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Auto Join Room \"459\"", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoJoinRoom459 : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Auto Join Room \"IDIOT\"", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoJoinRoomIDIOT : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Auto Join Room \"IIDK\"", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoJoinRoomIIDK : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Auto Join Room \"CRIMSON\"", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoJoinRoomCRIMSON : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Auto Join Room \"CAULDRON\"", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoJoinRoomCAULDRON : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Auto Join Room \"RUN\"", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoJoinRoomRUN : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Auto Join Room \"HIDE\"", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoJoinRoomHIDE : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Auto Join Room \"DAISY\"", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoJoinRoomDAISY : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Auto Join Room \"DAISY01\"", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoJoinRoomDAISY01 : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Auto Join Room \"DAISY09\"", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoJoinRoomDAISY09 : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Auto Join Room \"JV3U\"", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoJoinRoomJV3U : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Auto Join Room \"J3VU\"", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoJoinRoomJ3VU : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Auto Join Room \"PBBV\"", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoJoinRoomPBBV : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Auto Join Room \"BOT\"", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoJoinRoomBOT : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Auto Join Room \"LUCIO\"", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoJoinRoomLUCIO : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Auto Join Room \"VEN1\"", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoJoinRoomVEN1 : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Auto Join Room \"SREN16\"", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoJoinRoomSREN16 : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Auto Join Room \"SREN17\"", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoJoinRoomSREN17 : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Auto Join Room \"SREN18\"", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoJoinRoomSREN18 : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Auto Join Room \"HELP\"", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoJoinRoomHELP : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Auto Join Room \"STATUE\"", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoJoinRoomSTATUE : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Auto Join Room \"ECHO\"", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoJoinRoomECHO : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Auto Join Room \"MOD\"", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoJoinRoomMOD : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Auto Join Room \"MODS\"", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoJoinRoomMODS : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Auto Join Room \"HACK\"", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoJoinRoomHACK : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Auto Join Room \"HACKER\"", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoJoinRoomHACKER : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Auto Join Room \"LEMUR\"", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoJoinRoomLEMUR : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Auto Join Room \"JMANCURLY\"", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoJoinRoomJMANCURLY : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Auto Join Room \"JMAN\"", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoJoinRoomJMAN : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Auto Join Room \"ELLIOT\"", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoJoinRoomELLIOT : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Auto Join Room \"TYLERVR\"", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoJoinRoomTYLERVR : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Auto Join Room \"JUANGTAG\"", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoJoinRoomJUANGTAG : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Auto Join Room \"GHOST\"", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoJoinRoomGHOST : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Auto Join Room \"GULLIBLE\"", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoJoinRoomGULLIBLE : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Auto Join Room \"GAY\"", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoJoinRoomGAY : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Auto Join Room \"FURRY\"", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoJoinRoomFURRY : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Room)]
[ModInfo("Auto Join Room \"FORSAKEN\"", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoJoinRoomFORSAKEN : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
// ========== Utility ==========
[ModCategory(Cat.Utility)]
[ModInfo("Restart Gorilla Tag", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_RestartGorillaTag : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Open Gorilla Tag Folder", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_OpenGorillaTagFolder : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Discord RPC", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DiscordRPC : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Media Integration", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_MediaIntegration : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Anti Hand Tap", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AntiHandTap : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("First Person Camera", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FirstPersonCamera : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Force Enable Hands", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ForceEnableHands : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Oculus Report Menu [X]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_OculusReportMenuX : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Accept TOS", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AcceptTOS : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Bypass K-ID Restrictions", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BypassKIDRestrictions : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Redeem Shiny Rocks", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_RedeemShinyRocks : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Copy Player Position", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_CopyPlayerPosition : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Clear Notifications", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ClearNotifications : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Anti AFK", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AntiAFK : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Disable Network Triggers", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DisableNetworkTriggers : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Disable Map Triggers", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DisableMapTriggers : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Disable Quit Box", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DisableQuitBox : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Physical Quit Box", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PhysicalQuitBox : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Stump Quit Box", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_StumpQuitBox : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Block on Mute", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BlockonMute : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Steam Refund Timer", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SteamRefundTimer : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Advanced Ban Message", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AdvancedBanMessage : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("120 FPS", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_M120FPS : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("90 FPS", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_M90FPS : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("72 FPS", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_M72FPS : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("60 FPS", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_M60FPS : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("45 FPS", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_M45FPS : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("30 FPS", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_M30FPS : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("15 FPS", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_M15FPS : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Unlock FPS", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_UnlockFPS : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("PC Button Click", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PCButtonClick : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("PC Controller Emulation", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PCControllerEmulation : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Unlock Competitive Queue", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_UnlockCompetitiveQueue : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Change Queue to Default", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ChangeQueuetoDefault : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Change Queue to Minigames", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ChangeQueuetoMinigames : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Change Queue to Competitive", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ChangeQueuetoCompetitive : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Change Target Gamemode [Casual]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ChangeTargetGamemodeCasual : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Change Target Gamemode [Infection]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ChangeTargetGamemodeInfection : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Change Target Gamemode [Hunt]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ChangeTargetGamemodeHunt : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Change Target Gamemode [Paintbrawl]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ChangeTargetGamemodePaintbrawl : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Change Target Gamemode [Ambush]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ChangeTargetGamemodeAmbush : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Change Target Gamemode [Freeze Tag]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ChangeTargetGamemodeFreezeTag : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Change Target Gamemode [Ghost Tag]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ChangeTargetGamemodeGhostTag : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Change Target Gamemode [Custom]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ChangeTargetGamemodeCustom : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Change Target Gamemode [Guardian]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ChangeTargetGamemodeGuardian : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Change Target Gamemode [Prop Hunt]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ChangeTargetGamemodePropHunt : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Change Target Gamemode [Super Infection]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ChangeTargetGamemodeSuperInfection : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Change Target Gamemode [Error]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ChangeTargetGamemodeError : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Connect to US", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ConnecttoUS : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Connect to US West", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ConnecttoUSWest : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Connect to EU", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ConnecttoEU : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Utility)]
[ModInfo("Reauthenticate", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_Reauthenticate : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
// ========== Safety ==========
[ModCategory(Cat.Safety)]
[ModInfo("Recommended Safety Mods", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_RecommendedSafetyMods : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("No Finger Movement", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_NoFingerMovement : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Pull Your Id", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PullYourId : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Fake Oculus Menu [X]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FakeOculusMenuX : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Fake Report Menu [Y]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FakeReportMenuY : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Fake Broken Controller [X]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FakeBrokenControllerX : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Fake Power Off [J]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FakePowerOffJ : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Fake Valve Tracking [J]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FakeValveTrackingJ : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Disable Gamemode Buttons", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DisableGamemodeButtons : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Support Page Spoof", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SupportPageSpoof : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Flush RPCs", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FlushRPCs : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Anti Crash", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AntiCrash : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Anti Ban Crash", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AntiBanCrash : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Anti Kick", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AntiKick : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Anti Name Ban", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AntiNameBan : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Anti Stump Kick", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AntiStumpKick : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Auto Clear Cache", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoClearCache : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Anti Moderator", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AntiModerator : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Anti Content Creator", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AntiContentCreator : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Cosmetic Notifications", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_CosmeticNotifications : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Steam Detector", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SteamDetector : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Anti Report [Disconnect]", "ii port (client)", ButtonType.Fixed, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AntiReportDisconnect : MenuMod
{
    public override void Pressed() { Net.Disconnect(); }
}
[ModCategory(Cat.Safety)]
[ModInfo("Anti Report [Reconnect]", "ii port (client)", ButtonType.Fixed, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AntiReportReconnect : MenuMod
{
    public override void Pressed() { Net.Disconnect(); }
}
[ModCategory(Cat.Safety)]
[ModInfo("Anti Report [Join Random]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AntiReportJoinRandom : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Anti Report [Notify]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AntiReportNotify : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Anti Report [Overlay]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AntiReportOverlay : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Anti Report [Oculus]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AntiReportOculus : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Bypass Automod", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BypassAutomod : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Bypass Mod Checkers", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BypassModCheckers : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Bypass Cosmetic Check", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BypassCosmeticCheck : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Anti Predictions", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AntiPredictions : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Show Anti Cheat Reports [Self]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ShowAntiCheatReportsSelf : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Show Anti Cheat Reports [All]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ShowAntiCheatReportsAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Panic Button", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PanicButton : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Watchdog Auto-Leave", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_WatchdogAutoLeave : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Watchdog Mark All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_WatchdogMarkAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Watchdog Clear", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_WatchdogClear : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Mic Safety Gate", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_MicSafetyGate : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Change Identity", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ChangeIdentity : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Change Identity [Normal]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ChangeIdentityNormal : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Change Identity [Custom]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ChangeIdentityCustom : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Change Identity on Disconnect", "ii port (client)", ButtonType.Fixed, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ChangeIdentityonDisconnect : MenuMod
{
    public override void Pressed() { Net.Disconnect(); }
}
[ModCategory(Cat.Safety)]
[ModInfo("Change Identity on Disconnect [Normal]", "ii port (client)", ButtonType.Fixed, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ChangeIdentityonDisconnectNormal : MenuMod
{
    public override void Pressed() { Net.Disconnect(); }
}
[ModCategory(Cat.Safety)]
[ModInfo("Change Identity on Disconnect [Child]", "ii port (client)", ButtonType.Fixed, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ChangeIdentityonDisconnectChild : MenuMod
{
    public override void Pressed() { Net.Disconnect(); }
}
[ModCategory(Cat.Safety)]
[ModInfo("FPS Spoof", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FPSSpoof : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Ping Spoof", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PingSpoof : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Name Spoof", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_NameSpoof : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Color Spoof", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ColorSpoof : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Unload Menu", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_UnloadMenu : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Safety)]
[ModInfo("Disable Anti Telemetry", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DisableAntiTelemetry : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
// ========== Movement ==========
[ModCategory(Cat.Movement)]
[ModInfo("Platforms", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_Platforms : MenuMod
{
    public override string BindHint => "Grip";
    public override void OnDisable() => IiRt.ClearPlatforms();
    public override void Update() { if (Enabled) IiRt.Platforms(true); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Trigger Platforms", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_TriggerPlatforms : MenuMod
{
    public override string BindHint => "LT/RT";
    public override void OnDisable() => IiRt.ClearPlatforms();
    public override void Update() { if (Enabled) IiRt.Platforms(false); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Frozone", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_Frozone : MenuMod
{
    public override void FixedUpdate() { if (Enabled && H.Ready) H.Rb.AddForce(Vector3.up * 9.81f * 0.6f, ForceMode.Acceleration); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Platform Spam [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PlatformSpamG : MenuMod
{
    public override string BindHint => "Grip";
    public override void OnDisable() => IiRt.ClearPlatforms();
    public override void Update() { if (Enabled) IiRt.Platforms(true); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Platform Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PlatformGun : MenuMod
{
    public override string BindHint => "Grip";
    public override void OnDisable() => IiRt.ClearPlatforms();
    public override void Update() { if (Enabled) IiRt.Platforms(true); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Fly [A]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FlyA : MenuMod
{
    public override string BindHint => "A/RT";
    public override void Update() { if (Enabled && H.Ready && (H.A || H.RTrig)) IiRt.Fly(H.FlySpeed); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Trigger Fly [T]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_TriggerFlyT : MenuMod
{
    public override string BindHint => "A/RT";
    public override void Update() { if (Enabled && H.Ready && (H.A || H.RTrig)) IiRt.Fly(H.FlySpeed); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Noclip Fly [A]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_NoclipFlyA : MenuMod
{
    public override string BindHint => "RT";
    public override void OnDisable() => IiRt.Noclip(false);
    public override void Update() { IiRt.Noclip(Enabled && H.Ready && H.RTrig); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Joystick Fly [J]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_JoystickFlyJ : MenuMod
{
    public override string BindHint => "A/RT";
    public override void Update() { if (Enabled && H.Ready && (H.A || H.RTrig)) IiRt.Fly(H.FlySpeed); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Bark Fly [J]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BarkFlyJ : MenuMod
{
    public override string BindHint => "A/RT";
    public override void Update() { if (Enabled && H.Ready && (H.A || H.RTrig)) IiRt.Fly(H.FlySpeed); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Hand Fly [A]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_HandFlyA : MenuMod
{
    public override string BindHint => "A/RT";
    public override void Update() { if (Enabled && H.Ready && (H.A || H.RTrig)) IiRt.Fly(H.FlySpeed); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Fly Towards Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FlyTowardsGun : MenuMod
{
    public override string BindHint => "A/RT";
    public override void Update() { if (Enabled && H.Ready && (H.A || H.RTrig)) IiRt.Fly(H.FlySpeed); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Slingshot Fly [A]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SlingshotFlyA : MenuMod
{
    public override string BindHint => "A/RT";
    public override void Update() { if (Enabled && H.Ready && (H.A || H.RTrig)) IiRt.Fly(H.FlySpeed); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Zero Gravity Slingshot Fly [A]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ZeroGravitySlingshotFlyA : MenuMod
{
    public override string BindHint => "A/RT";
    public override void Update() { if (Enabled && H.Ready && (H.A || H.RTrig)) IiRt.Fly(H.FlySpeed); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Slingshot Bark Fly [J]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SlingshotBarkFlyJ : MenuMod
{
    public override string BindHint => "A/RT";
    public override void Update() { if (Enabled && H.Ready && (H.A || H.RTrig)) IiRt.Fly(H.FlySpeed); }
}
[ModCategory(Cat.Movement)]
[ModInfo("WASD Fly", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_WASDFly : MenuMod
{
    public override string BindHint => "A/RT";
    public override void Update() { if (Enabled && H.Ready && (H.A || H.RTrig)) IiRt.Fly(H.FlySpeed); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Dash [A]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DashA : MenuMod
{
    public override string BindHint => "A";
    private bool _was;
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        bool now = H.A; if (now && !_was) H.Rb.AddForce(H.Look.forward * 12f, ForceMode.VelocityChange); _was = now;
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Reverse Velocity [A]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ReverseVelocityA : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Bird Fly", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BirdFly : MenuMod
{
    public override string BindHint => "A/RT";
    public override void Update() { if (Enabled && H.Ready && (H.A || H.RTrig)) IiRt.Fly(H.FlySpeed); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Iron Man", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_IronMan : MenuMod
{
    public override string BindHint => "A/RT";
    public override void Update() { if (Enabled && H.Ready && (H.A || H.RTrig)) IiRt.Fly(H.FlySpeed); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Spider Man", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SpiderMan : MenuMod
{
    public override string BindHint => "Grip";
    public override void FixedUpdate() { if (Enabled) IiRt.WallWalk(); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Grappling Hooks", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GrapplingHooks : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Portal Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PortalGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Drive [J]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DriveJ : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Hard Drive [J]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_HardDriveJ : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Noclip [T]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_NoclipT : MenuMod
{
    public override string BindHint => "RT";
    public override void OnDisable() => IiRt.Noclip(false);
    public override void Update() { IiRt.Noclip(Enabled && H.Ready && H.RTrig); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Up And Down", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_UpAndDown : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Left And Right", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_LeftAndRight : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Forwards And Backwards", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ForwardsAndBackwards : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Size Changer", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SizeChanger : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Auto Walk [J]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoWalkJ : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Auto Funny Run [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoFunnyRunG : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Auto Pinch Climb [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoPinchClimbG : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Auto Elevator Climb [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoElevatorClimbG : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Auto Branch [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoBranchG : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Force Tag Freeze", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ForceTagFreeze : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("No Tag Freeze", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_NoTagFreeze : MenuMod
{
    public override void Update() { if (Enabled) IiRt.TagNear(3f); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Feather Falling", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FeatherFalling : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Low Gravity", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_LowGravity : MenuMod
{
    public override void FixedUpdate() { if (Enabled && H.Ready) H.Rb.AddForce(Vector3.up * 9.81f * 0.6f, ForceMode.Acceleration); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Zero Gravity", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ZeroGravity : MenuMod
{
    public override void FixedUpdate() { if (Enabled && H.Ready) H.Rb.AddForce(Vector3.up * 9.81f, ForceMode.Acceleration); }
}
[ModCategory(Cat.Movement)]
[ModInfo("High Gravity", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_HighGravity : MenuMod
{
    public override void FixedUpdate() { if (Enabled && H.Ready) H.Rb.AddForce(Vector3.down * 9.81f, ForceMode.Acceleration); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Reverse Gravity", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ReverseGravity : MenuMod
{
    public override void FixedUpdate() { if (Enabled && H.Ready) H.Rb.AddForce(Vector3.up * 19.62f, ForceMode.Acceleration); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Rewind [T]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_RewindT : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Macros", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_Macros : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Wall Walk [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_WallWalkG : MenuMod
{
    public override string BindHint => "Grip";
    public override void FixedUpdate() { if (Enabled) IiRt.WallWalk(); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Legitimate Wall Walk [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_LegitimateWallWalkG : MenuMod
{
    public override string BindHint => "Grip";
    public override void FixedUpdate() { if (Enabled) IiRt.WallWalk(); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Spider Walk", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SpiderWalk : MenuMod
{
    public override string BindHint => "Grip";
    public override void FixedUpdate() { if (Enabled) IiRt.WallWalk(); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Teleport to Random", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_TeleporttoRandom : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() {
        if (!Enabled || !H.Ready || !H.RTrig || Time.time < _n) return;
        _n = Time.time + 0.4f;
        Vector3 d = H.Look.forward; d.y = 0f; if (d.sqrMagnitude < 0.01f) d = H.Look.forward; d.Normalize();
        H.Teleport(H.Head.position + d * 5f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Teleport to Map", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_TeleporttoMap : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() {
        if (!Enabled || !H.Ready || !H.RTrig || Time.time < _n) return;
        _n = Time.time + 0.4f;
        Vector3 d = H.Look.forward; d.y = 0f; if (d.sqrMagnitude < 0.01f) d = H.Look.forward; d.Normalize();
        H.Teleport(H.Head.position + d * 5f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Teleport Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_TeleportGun : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() {
        if (!Enabled || !H.Ready || !H.RTrig || Time.time < _n) return;
        _n = Time.time + 0.4f;
        Vector3 d = H.Look.forward; d.y = 0f; if (d.sqrMagnitude < 0.01f) d = H.Look.forward; d.Normalize();
        H.Teleport(H.Head.position + d * 5f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Airstrike", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_Airstrike : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Checkpoint [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_CheckpointG : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() {
        if (!Enabled || !H.Ready || !H.RTrig || Time.time < _n) return;
        _n = Time.time + 0.4f;
        Vector3 d = H.Look.forward; d.y = 0f; if (d.sqrMagnitude < 0.01f) d = H.Look.forward; d.Normalize();
        H.Teleport(H.Head.position + d * 5f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Advanced Checkpoints [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AdvancedCheckpointsG : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() {
        if (!Enabled || !H.Ready || !H.RTrig || Time.time < _n) return;
        _n = Time.time + 0.4f;
        Vector3 d = H.Look.forward; d.y = 0f; if (d.sqrMagnitude < 0.01f) d = H.Look.forward; d.Normalize();
        H.Teleport(H.Head.position + d * 5f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Ender Pearl [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_EnderPearlG : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("C4 [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_C4G : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Punch Mod", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PunchMod : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Telekinesis", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_Telekinesis : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Safety Bubble", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SafetyBubble : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Solid Players", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SolidPlayers : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Pull Mod [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PullModG : MenuMod
{
    public override string BindHint => "RG+RT";
    public override void Update() { if (Enabled) IiRt.PullGun(); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Long Jump [A]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_LongJumpA : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Velocity Long Arms", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_VelocityLongArms : MenuMod
{
    public override void LateUpdate() { if (Enabled) IiRt.LongArms(1.5f); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Timer", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_Timer : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Speed Boost", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SpeedBoost : MenuMod
{
    public override void Update() { if (Enabled) IiRt.Speed(1.35f); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Grip Speed Boost", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GripSpeedBoost : MenuMod
{
    public override void Update() { if (Enabled) IiRt.Speed(1.35f); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Dynamic Speed Boost", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DynamicSpeedBoost : MenuMod
{
    public override void Update() { if (Enabled) IiRt.Speed(1.35f); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Uncap Max Velocity", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_UncapMaxVelocity : MenuMod
{
    public override void Update() { if (Enabled) IiRt.Speed(1.35f); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Always Max Velocity", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AlwaysMaxVelocity : MenuMod
{
    public override void Update() { if (Enabled) IiRt.Speed(1.35f); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Disable Velocity Cap", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DisableVelocityCap : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Funny Movement", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FunnyMovement : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Slip Slap", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SlipSlap : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Slippery Hands", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SlipperyHands : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Grippy Hands", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GrippyHands : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Slippery Surface Helper", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SlipperySurfaceHelper : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Remove Forest Colliders", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_RemoveForestColliders : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Sticky Hands", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_StickyHands : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Climby Hands", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ClimbyHands : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Disable Hands", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DisableHands : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Disable Body Collider", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DisableBodyCollider : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Disable Head Collider", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DisableHeadCollider : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Slide Control", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SlideControl : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Weak Slide Control", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_WeakSlideControl : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Throw Controllers", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ThrowControllers : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Controller Flick", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ControllerFlick : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Uncap Arm Length", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_UncapArmLength : MenuMod
{
    public override void LateUpdate() { if (Enabled) IiRt.LongArms(1.5f); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Steam Long Arms", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SteamLongArms : MenuMod
{
    public override void LateUpdate() { if (Enabled) IiRt.LongArms(1.5f); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Stick Long Arms", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_StickLongArms : MenuMod
{
    public override void LateUpdate() { if (Enabled) IiRt.LongArms(1.5f); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Multiplied Long Arms", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_MultipliedLongArms : MenuMod
{
    public override void LateUpdate() { if (Enabled) IiRt.LongArms(1.5f); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Vertical Long Arms", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_VerticalLongArms : MenuMod
{
    public override void LateUpdate() { if (Enabled) IiRt.LongArms(1.5f); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Horizontal Long Arms", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_HorizontalLongArms : MenuMod
{
    public override void LateUpdate() { if (Enabled) IiRt.LongArms(1.5f); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Extenders [J]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ExtendersJ : MenuMod
{
    public override void LateUpdate() { if (Enabled) IiRt.LongArms(1.5f); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Flick Jump [A]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FlickJumpA : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Bunny Hop", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BunnyHop : MenuMod
{
    public override string BindHint => "A";
    private bool _was;
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        bool now = H.A; if (now && !_was) H.Rb.AddForce(H.Look.forward * 12f, ForceMode.VelocityChange); _was = now;
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Strafe", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_Strafe : MenuMod
{
    public override string BindHint => "A";
    private bool _was;
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        bool now = H.A; if (now && !_was) H.Rb.AddForce(H.Look.forward * 12f, ForceMode.VelocityChange); _was = now;
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Dynamic Strafe", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DynamicStrafe : MenuMod
{
    public override string BindHint => "A";
    private bool _was;
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        bool now = H.A; if (now && !_was) H.Rb.AddForce(H.Look.forward * 12f, ForceMode.VelocityChange); _was = now;
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Ground Helper [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GroundHelperG : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Bouncy", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_Bouncy : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Solid Water", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SolidWater : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Disable Water", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DisableWater : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Air Swim", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AirSwim : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Fast Swim", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FastSwim : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Water Run Helper", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_WaterRunHelper : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Disable Air", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DisableAir : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Ghost [A]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GhostA : MenuMod
{
    public override void OnEnable()  => IiRt.SetLocalVisible(false);
    public override void OnDisable() => IiRt.SetLocalVisible(true);
    public override void Update()    { if (Enabled) IiRt.SetLocalVisible(false); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Invisible [B]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_InvisibleB : MenuMod
{
    public override void OnEnable()  => IiRt.SetLocalVisible(false);
    public override void OnDisable() => IiRt.SetLocalVisible(true);
    public override void Update()    { if (Enabled) IiRt.SetLocalVisible(false); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Rig Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_RigGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Grab Rig [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GrabRigG : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Spin Head X", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SpinHeadX : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Spin Head Y", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SpinHeadY : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Spin Head Z", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SpinHeadZ : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Spaz Rig [A]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SpazRigA : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Spaz Rig Hands [A]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SpazRigHandsA : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Spaz Hands [A]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SpazHandsA : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Random Spaz Head Position", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_RandomSpazHeadPosition : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Random Spaz Head", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_RandomSpazHead : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Spaz Head Position", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SpazHeadPosition : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Spaz Head", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SpazHead : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Spaz Head X", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SpazHeadX : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Spaz Head Y", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SpazHeadY : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Spaz Head Z", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SpazHeadZ : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Laggy Rig", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_LaggyRig : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Smooth Rig", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SmoothRig : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Update Rig [A]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_UpdateRigA : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Freeze Rig Limbs", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FreezeRigLimbs : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Freeze Rig Body", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FreezeRigBody : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Freeze Rig", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FreezeRig : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Paralyze Rig", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ParalyzeRig : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Chicken Rig", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ChickenRig : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Amputate Rig", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AmputateRig : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Decapitate Rig", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DecapitateRig : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Spin Rig Body", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SpinRigBody : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Spaz Rig Body", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SpazRigBody : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Reverse Rig Body", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ReverseRigBody : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Rec Room Body", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_RecRoomBody : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Freeze Body Rotation [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FreezeBodyRotationG : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Auto Dance [A]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoDanceA : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Auto Griddy [A]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoGriddyA : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Auto T Pose [A]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoTPoseA : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Helicopter [A]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_HelicopterA : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Beyblade [A]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BeybladeA : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Still Beyblade [A]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_StillBeybladeA : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Spin Bot", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SpinBot : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Fan [A]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FanA : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Ghost Animations", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GhostAnimations : MenuMod
{
    public override void OnEnable()  => IiRt.SetLocalVisible(false);
    public override void OnDisable() => IiRt.SetLocalVisible(true);
    public override void Update()    { if (Enabled) IiRt.SetLocalVisible(false); }
}
[ModCategory(Cat.Movement)]
[ModInfo("Minecraft Animations", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_MinecraftAnimations : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Stare at Nearby", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_StareatNearby : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Stare at Player Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_StareatPlayerGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Stare at All Players", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_StareatAllPlayers : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Eye Contact", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_EyeContact : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Floating Rig", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FloatingRig : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Bees", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_Bees : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Bees [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BeesG : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Piggyback Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PiggybackGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Piggyback All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PiggybackAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Copy Movement Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_CopyMovementGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Copy Movement All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_CopyMovementAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Follow Player Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FollowPlayerGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Follow All Players", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FollowAllPlayers : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Orbit Player Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_OrbitPlayerGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Orbit All Players", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_OrbitAllPlayers : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Jumpscare Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_JumpscareGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Jumpscare All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_JumpscareAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Annoy Player Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AnnoyPlayerGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Annoy All Players", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AnnoyAllPlayers : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Intercourse Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_IntercourseGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Intercourse All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_IntercourseAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Head Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_HeadGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Movement)]
[ModInfo("Head All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_HeadAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
// ========== Advantage ==========
[ModCategory(Cat.Advantage)]
[ModInfo("Tag Self", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_TagSelf : MenuMod
{
    public override void Update() { if (Enabled) IiRt.TagNear(3f); }
}
[ModCategory(Cat.Advantage)]
[ModInfo("Tag Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_TagGun : MenuMod
{
    public override string BindHint => "RT";
    public override void Update() { if (Enabled) IiRt.TagAim(); }
}
[ModCategory(Cat.Advantage)]
[ModInfo("Tag All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_TagAll : MenuMod
{
    public override void Update() { if (Enabled) IiRt.TagAll(); }
}
[ModCategory(Cat.Advantage)]
[ModInfo("Tag Aura", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_TagAura : MenuMod
{
    public override void Update() { if (Enabled) IiRt.TagNear(3f); }
}
[ModCategory(Cat.Advantage)]
[ModInfo("Grip Tag Aura [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GripTagAuraG : MenuMod
{
    public override void Update() { if (Enabled) IiRt.TagNear(3f); }
}
[ModCategory(Cat.Advantage)]
[ModInfo("Tag Aura Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_TagAuraGun : MenuMod
{
    public override string BindHint => "RT";
    public override void Update() { if (Enabled) IiRt.TagAim(); }
}
[ModCategory(Cat.Advantage)]
[ModInfo("Tag Aura All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_TagAuraAll : MenuMod
{
    public override void Update() { if (Enabled) IiRt.TagAll(); }
}
[ModCategory(Cat.Advantage)]
[ModInfo("Tag Reach", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_TagReach : MenuMod
{
    public override void Update() { /* hitbox style: use Tag Nearby range */ if (Enabled && H.Ready) IiRt.TagNear(5f); }
}
[ModCategory(Cat.Advantage)]
[ModInfo("Flick Tag Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FlickTagGun : MenuMod
{
    public override string BindHint => "RT";
    public override void Update() { if (Enabled) IiRt.TagAim(); }
}
[ModCategory(Cat.Advantage)]
[ModInfo("Tag Bot", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_TagBot : MenuMod
{
    public override void Update() { if (Enabled) IiRt.TagNear(3f); }
}
[ModCategory(Cat.Advantage)]
[ModInfo("No Tag on Join", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_NoTagonJoin : MenuMod
{
    public override void Update() { if (Enabled) IiRt.TagNear(3f); }
}
[ModCategory(Cat.Advantage)]
[ModInfo("Untag Self", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_UntagSelf : MenuMod
{
    public override void Update() { if (Enabled) IiRt.TagNear(3f); }
}
[ModCategory(Cat.Advantage)]
[ModInfo("Anti Tag", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AntiTag : MenuMod
{
    public override void Update() { if (Enabled) IiRt.TagNear(3f); }
}
[ModCategory(Cat.Advantage)]
[ModInfo("Report Anti Tag", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ReportAntiTag : MenuMod
{
    public override void Update() { if (Enabled) IiRt.TagNear(3f); }
}
[ModCategory(Cat.Advantage)]
[ModInfo("No Tag Limit", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_NoTagLimit : MenuMod
{
    public override void Update() { if (Enabled) IiRt.TagNear(3f); }
}
[ModCategory(Cat.Advantage)]
[ModInfo("Tag Lag Detector", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_TagLagDetector : MenuMod
{
    public override void Update() { if (Enabled) IiRt.TagNear(3f); }
}
[ModCategory(Cat.Advantage)]
[ModInfo("Fake Lag", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FakeLag : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Advantage)]
[ModInfo("Lag Range", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_LagRange : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Advantage)]
[ModInfo("Blink", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_Blink : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() {
        if (!Enabled || !H.Ready || !H.RTrig || Time.time < _n) return;
        _n = Time.time + 0.4f;
        Vector3 d = H.Look.forward; d.y = 0f; if (d.sqrMagnitude < 0.01f) d = H.Look.forward; d.Normalize();
        H.Teleport(H.Head.position + d * 5f);
    }
}
[ModCategory(Cat.Advantage)]
[ModInfo("Paintbrawl Aimbot", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PaintbrawlAimbot : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Advantage)]
[ModInfo("Slingshot Helper", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SlingshotHelper : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Advantage)]
[ModInfo("Slingshot Trigger Bot", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SlingshotTriggerBot : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Advantage)]
[ModInfo("Paintbrawl Kill Self", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PaintbrawlKillSelf : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Advantage)]
[ModInfo("Paintbrawl Kill Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PaintbrawlKillGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Advantage)]
[ModInfo("Paintbrawl Kill All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PaintbrawlKillAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
// ========== Sound ==========
[ModCategory(Cat.Sound)]
[ModInfo("Soundboard", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_Soundboard : MenuMod
{
    public override string BindHint => "Grip";
    public override void Update() { if (Enabled && (H.LGrip||H.RGrip)) { /* plays via soundboard if loaded */ } }
}
[ModCategory(Cat.Sound)]
[ModInfo("Bass Sound Spam [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BassSoundSpamG : MenuMod
{
    public override string BindHint => "Grip";
    public override void Update() { if (Enabled && (H.LGrip||H.RGrip)) { /* plays via soundboard if loaded */ } }
}
[ModCategory(Cat.Sound)]
[ModInfo("Metal Sound Spam [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_MetalSoundSpamG : MenuMod
{
    public override string BindHint => "Grip";
    public override void Update() { if (Enabled && (H.LGrip||H.RGrip)) { /* plays via soundboard if loaded */ } }
}
[ModCategory(Cat.Sound)]
[ModInfo("Wolf Sound Spam [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_WolfSoundSpamG : MenuMod
{
    public override string BindHint => "Grip";
    public override void Update() { if (Enabled && (H.LGrip||H.RGrip)) { /* plays via soundboard if loaded */ } }
}
[ModCategory(Cat.Sound)]
[ModInfo("Cat Sound Spam [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_CatSoundSpamG : MenuMod
{
    public override string BindHint => "Grip";
    public override void Update() { if (Enabled && (H.LGrip||H.RGrip)) { /* plays via soundboard if loaded */ } }
}
[ModCategory(Cat.Sound)]
[ModInfo("Turkey Sound Spam [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_TurkeySoundSpamG : MenuMod
{
    public override string BindHint => "Grip";
    public override void Update() { if (Enabled && (H.LGrip||H.RGrip)) { /* plays via soundboard if loaded */ } }
}
[ModCategory(Cat.Sound)]
[ModInfo("Frog Sound Spam [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FrogSoundSpamG : MenuMod
{
    public override string BindHint => "Grip";
    public override void Update() { if (Enabled && (H.LGrip||H.RGrip)) { /* plays via soundboard if loaded */ } }
}
[ModCategory(Cat.Sound)]
[ModInfo("Bee Sound Spam [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BeeSoundSpamG : MenuMod
{
    public override string BindHint => "Grip";
    public override void Update() { if (Enabled && (H.LGrip||H.RGrip)) { /* plays via soundboard if loaded */ } }
}
[ModCategory(Cat.Sound)]
[ModInfo("Squeak Sound Spam [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SqueakSoundSpamG : MenuMod
{
    public override string BindHint => "Grip";
    public override void Update() { if (Enabled && (H.LGrip||H.RGrip)) { /* plays via soundboard if loaded */ } }
}
[ModCategory(Cat.Sound)]
[ModInfo("Okay Sound Spam [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_OkaySoundSpamG : MenuMod
{
    public override string BindHint => "Grip";
    public override void Update() { if (Enabled && (H.LGrip||H.RGrip)) { /* plays via soundboard if loaded */ } }
}
[ModCategory(Cat.Sound)]
[ModInfo("Scream Sound Spam [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ScreamSoundSpamG : MenuMod
{
    public override string BindHint => "Grip";
    public override void Update() { if (Enabled && (H.LGrip||H.RGrip)) { /* plays via soundboard if loaded */ } }
}
[ModCategory(Cat.Sound)]
[ModInfo("Slap Sound Spam [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SlapSoundSpamG : MenuMod
{
    public override string BindHint => "Grip";
    public override void Update() { if (Enabled && (H.LGrip||H.RGrip)) { /* plays via soundboard if loaded */ } }
}
[ModCategory(Cat.Sound)]
[ModInfo("Jmancurly Sound Spam [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_JmancurlySoundSpamG : MenuMod
{
    public override string BindHint => "Grip";
    public override void Update() { if (Enabled && (H.LGrip||H.RGrip)) { /* plays via soundboard if loaded */ } }
}
[ModCategory(Cat.Sound)]
[ModInfo("Random Sound Spam [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_RandomSoundSpamG : MenuMod
{
    public override string BindHint => "Grip";
    public override void Update() { if (Enabled && (H.LGrip||H.RGrip)) { /* plays via soundboard if loaded */ } }
}
[ModCategory(Cat.Sound)]
[ModInfo("Earrape Sound Spam [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_EarrapeSoundSpamG : MenuMod
{
    public override string BindHint => "Grip";
    public override void Update() { if (Enabled && (H.LGrip||H.RGrip)) { /* plays via soundboard if loaded */ } }
}
[ModCategory(Cat.Sound)]
[ModInfo("Ding Sound Spam [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DingSoundSpamG : MenuMod
{
    public override string BindHint => "Grip";
    public override void Update() { if (Enabled && (H.LGrip||H.RGrip)) { /* plays via soundboard if loaded */ } }
}
[ModCategory(Cat.Sound)]
[ModInfo("Crystal Sound Spam [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_CrystalSoundSpamG : MenuMod
{
    public override string BindHint => "Grip";
    public override void Update() { if (Enabled && (H.LGrip||H.RGrip)) { /* plays via soundboard if loaded */ } }
}
[ModCategory(Cat.Sound)]
[ModInfo("Piano Sound Spam [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PianoSoundSpamG : MenuMod
{
    public override string BindHint => "Grip";
    public override void Update() { if (Enabled && (H.LGrip||H.RGrip)) { /* plays via soundboard if loaded */ } }
}
[ModCategory(Cat.Sound)]
[ModInfo("Big Crystal Sound Spam [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BigCrystalSoundSpamG : MenuMod
{
    public override string BindHint => "Grip";
    public override void Update() { if (Enabled && (H.LGrip||H.RGrip)) { /* plays via soundboard if loaded */ } }
}
[ModCategory(Cat.Sound)]
[ModInfo("Pan Sound Spam [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PanSoundSpamG : MenuMod
{
    public override string BindHint => "Grip";
    public override void Update() { if (Enabled && (H.LGrip||H.RGrip)) { /* plays via soundboard if loaded */ } }
}
[ModCategory(Cat.Sound)]
[ModInfo("AK-47 Sound Spam [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AK47SoundSpamG : MenuMod
{
    public override string BindHint => "Grip";
    public override void Update() { if (Enabled && (H.LGrip||H.RGrip)) { /* plays via soundboard if loaded */ } }
}
[ModCategory(Cat.Sound)]
[ModInfo("Siren Sound Spam [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SirenSoundSpamG : MenuMod
{
    public override string BindHint => "Grip";
    public override void Update() { if (Enabled && (H.LGrip||H.RGrip)) { /* plays via soundboard if loaded */ } }
}
[ModCategory(Cat.Sound)]
[ModInfo("Tick Sound Spam [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_TickSoundSpamG : MenuMod
{
    public override string BindHint => "Grip";
    public override void Update() { if (Enabled && (H.LGrip||H.RGrip)) { /* plays via soundboard if loaded */ } }
}
[ModCategory(Cat.Sound)]
[ModInfo("Custom Sound ID", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_CustomSoundID : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Sound)]
[ModInfo("Custom Sound Spam", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_CustomSoundSpam : MenuMod
{
    public override string BindHint => "Grip";
    public override void Update() { if (Enabled && (H.LGrip||H.RGrip)) { /* plays via soundboard if loaded */ } }
}
[ModCategory(Cat.Sound)]
[ModInfo("Override Tap Sound", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_OverrideTapSound : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
// ========== Projectile ==========
[ModCategory(Cat.Projectile)]
[ModInfo("Grab Projectile [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GrabProjectileG : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Projectile Spam [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ProjectileSpamG : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Projectile Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ProjectileGun : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Laser Spam [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_LaserSpamG : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Give Projectile Spam Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GiveProjectileSpamGun : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Impact Spam", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ImpactSpam : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Laser Eyes [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_LaserEyesG : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Urine [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_UrineG : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Feces [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FecesG : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Period [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PeriodG : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Semen [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SemenG : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Vomit [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_VomitG : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Spit [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SpitG : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Laser Eyes Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_LaserEyesGun : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Urine Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_UrineGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Feces Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FecesGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Period Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PeriodGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Semen Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SemenGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Vomit Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_VomitGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Spit Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SpitGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Projectile Blind Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ProjectileBlindGun : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Projectile Blind All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ProjectileBlindAll : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Projectile Lag Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ProjectileLagGun : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Projectile Lag All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ProjectileLagAll : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Snowball Spam [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SnowballSpamG : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Snowball Minigun [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SnowballMinigunG : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Give Snowball Minigun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GiveSnowballMinigun : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Snowball Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SnowballGun : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Snowball Nuke Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SnowballNukeGun : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Snowball Airstrike Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SnowballAirstrikeGun : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Snowball Rain [T]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SnowballRainT : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Snowball Hail [T]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SnowballHailT : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Snowball Fountain [T]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SnowballFountainT : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Snowball Positional Fountain [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SnowballPositionalFountainG : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Snowball Orbit [T]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SnowballOrbitT : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Snowball Aura [T]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SnowballAuraT : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Snowball Mushroom [T]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SnowballMushroomT : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Snowball Shotgun [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SnowballShotgunG : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Snowball Wall [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SnowballWallG : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Snowball C4 [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SnowballC4G : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Snowball Grenade [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SnowballGrenadeG : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Snowball RPG [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SnowballRPGG : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Snowball Punch Mod", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SnowballPunchMod : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Snowball Boxing", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SnowballBoxing : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Snowball Dash [A]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SnowballDashA : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Snowball High Jump", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SnowballHighJump : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Snowball Particle Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SnowballParticleGun : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Snowball Impact Effect Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SnowballImpactEffectGun : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Snowball Kamehameha", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SnowballKamehameha : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Snowball Fling Zone [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SnowballFlingZoneG : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Snowball Fling Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SnowballFlingGun : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Snowball Fling All [T]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SnowballFlingAllT : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Snowball Fling Aura", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SnowballFlingAura : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Snowball Fling Vertical Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SnowballFlingVerticalGun : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Snowball Fling Vertical All [T]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SnowballFlingVerticalAllT : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Snowball Fling Towards Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SnowballFlingTowardsGun : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Snowball Fling Away Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SnowballFlingAwayGun : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Snowball Fling Player Towards Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SnowballFlingPlayerTowardsGun : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Snowball Fling Player Away Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SnowballFlingPlayerAwayGun : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
[ModCategory(Cat.Projectile)]
[ModInfo("Snowball Launch Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SnowballLaunchGun : MenuMod
{
    public override string BindHint => "RT";
    private float _n;
    public override void Update() { if (!Enabled || !H.RTrig || Time.time < _n) return; _n = Time.time + 0.12f; IiRt.ShootPrim(); }
}
// ========== Master ==========
[ModCategory(Cat.Master)]
[ModInfo("MasterLabel", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_MasterLabel : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Guardian Self", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GuardianSelf : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Guardian Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GuardianGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Guardian All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GuardianAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Unguardian Self", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_UnguardianSelf : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Unguardian Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_UnguardianGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Unguardian All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_UnguardianAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Guardian Spaz", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GuardianSpaz : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Red Color Self", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_RedColorSelf : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Red Color Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_RedColorGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Red Color All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_RedColorAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Blue Color Self", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BlueColorSelf : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Blue Color Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BlueColorGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Blue Color All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BlueColorAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Reset Color Self", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ResetColorSelf : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Reset Color Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ResetColorGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Reset Color All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ResetColorAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Strobe Color Self", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_StrobeColorSelf : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Strobe Color Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_StrobeColorGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Strobe Color All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_StrobeColorAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Material Self", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_MaterialSelf : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Material Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_MaterialGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Material All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_MaterialAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Grey Screen Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GreyScreenGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Fix Screen Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FixScreenGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Grey Screen All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GreyScreenAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Spaz Grey Screen Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SpazGreyScreenGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Spaz Grey Screen All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SpazGreyScreenAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Zero Gravity Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ZeroGravityGun : MenuMod
{
    public override void FixedUpdate() { if (Enabled && H.Ready) H.Rb.AddForce(Vector3.up * 9.81f, ForceMode.Acceleration); }
}
[ModCategory(Cat.Master)]
[ModInfo("Zero Gravity All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ZeroGravityAll : MenuMod
{
    public override void FixedUpdate() { if (Enabled && H.Ready) H.Rb.AddForce(Vector3.up * 9.81f, ForceMode.Acceleration); }
}
[ModCategory(Cat.Master)]
[ModInfo("Fix Gravity Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FixGravityGun : MenuMod
{
    public override void FixedUpdate() { if (Enabled && H.Ready) H.Rb.AddForce(Vector3.up * 9.81f * 0.6f, ForceMode.Acceleration); }
}
[ModCategory(Cat.Master)]
[ModInfo("Spaz Prop Hunt", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SpazPropHunt : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Spaz Prop Hunt Objects", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SpazPropHuntObjects : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Max Currency Self", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_MaxCurrencySelf : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Max Currency Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_MaxCurrencyGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Max Currency All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_MaxCurrencyAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Add Currency Self", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AddCurrencySelf : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Add Currency Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AddCurrencyGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Add Currency All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AddCurrencyAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Remove Currency Self", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_RemoveCurrencySelf : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Remove Currency Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_RemoveCurrencyGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Remove Currency All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_RemoveCurrencyAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Invincibility", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_Invincibility : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Start Shift", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_StartShift : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("End Shift", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_EndShift : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Set Quota", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SetQuota : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Virtual Stump Kick Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_VirtualStumpKickGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Virtual Stump Kick All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_VirtualStumpKickAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Virtual Stump Crash Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_VirtualStumpCrashGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Virtual Stump Crash All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_VirtualStumpCrashAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Ghost Reactor Freeze Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GhostReactorFreezeGun : MenuMod
{
    public override void OnEnable()  => IiRt.SetLocalVisible(false);
    public override void OnDisable() => IiRt.SetLocalVisible(true);
    public override void Update()    { if (Enabled) IiRt.SetLocalVisible(false); }
}
[ModCategory(Cat.Master)]
[ModInfo("Ghost Reactor Freeze All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GhostReactorFreezeAll : MenuMod
{
    public override void OnEnable()  => IiRt.SetLocalVisible(false);
    public override void OnDisable() => IiRt.SetLocalVisible(true);
    public override void Update()    { if (Enabled) IiRt.SetLocalVisible(false); }
}
[ModCategory(Cat.Master)]
[ModInfo("Ghost Reactor Crash Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GhostReactorCrashGun : MenuMod
{
    public override void OnEnable()  => IiRt.SetLocalVisible(false);
    public override void OnDisable() => IiRt.SetLocalVisible(true);
    public override void Update()    { if (Enabled) IiRt.SetLocalVisible(false); }
}
[ModCategory(Cat.Master)]
[ModInfo("Ghost Reactor Crash All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GhostReactorCrashAll : MenuMod
{
    public override void OnEnable()  => IiRt.SetLocalVisible(false);
    public override void OnDisable() => IiRt.SetLocalVisible(true);
    public override void Update()    { if (Enabled) IiRt.SetLocalVisible(false); }
}
[ModCategory(Cat.Master)]
[ModInfo("Super Infection Crash Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SuperInfectionCrashGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Super Infection Crash All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SuperInfectionCrashAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Super Infection Break Audio Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SuperInfectionBreakAudioGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Super Infection Break Audio All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SuperInfectionBreakAudioAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Kill Self", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_KillSelf : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Kill Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_KillGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Kill All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_KillAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Revive Self", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ReviveSelf : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Revive Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ReviveGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Revive All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ReviveAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Spaz Kill Self", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SpazKillSelf : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Spaz Kill Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SpazKillGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Spaz Kill All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SpazKillAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Unlimited Building", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_UnlimitedBuilding : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Shotgun [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ShotgunG : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Block Crash Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BlockCrashGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Block Crash All [T]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BlockCrashAllT : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Block Draw Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BlockDrawGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Block Build Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BlockBuildGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Block Tower Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BlockTowerGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Block Freeze Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BlockFreezeGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Block Freeze All [T]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BlockFreezeAllT : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Block Float Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BlockFloatGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Building Block Fling Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BuildingBlockFlingGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Building Block Bring Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BuildingBlockBringGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Building Block Push Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BuildingBlockPushGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Spaz Targets", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SpazTargets : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Slow Monsters", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SlowMonsters : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Fast Monsters", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FastMonsters : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Grab Monsters [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GrabMonstersG : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Monster Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_MonsterGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Spaz Monsters", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SpazMonsters : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Orbit Monsters", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_OrbitMonsters : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Destroy Monsters", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DestroyMonsters : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Infection to Tag", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_InfectiontoTag : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Tag to Infection", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_TagtoInfection : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Untag Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_UntagGun : MenuMod
{
    public override string BindHint => "RT";
    public override void Update() { if (Enabled) IiRt.TagAim(); }
}
[ModCategory(Cat.Master)]
[ModInfo("Untag All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_UntagAll : MenuMod
{
    public override void Update() { if (Enabled) IiRt.TagAll(); }
}
[ModCategory(Cat.Master)]
[ModInfo("Break Tag", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BreakTag : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Spam Tag Self", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SpamTagSelf : MenuMod
{
    public override void Update() { if (Enabled) IiRt.TagNear(3f); }
}
[ModCategory(Cat.Master)]
[ModInfo("Spam Tag Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SpamTagGun : MenuMod
{
    public override string BindHint => "RT";
    public override void Update() { if (Enabled) IiRt.TagAim(); }
}
[ModCategory(Cat.Master)]
[ModInfo("Spam Tag All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SpamTagAll : MenuMod
{
    public override void Update() { if (Enabled) IiRt.TagAll(); }
}
[ModCategory(Cat.Master)]
[ModInfo("Rock Self", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_RockSelf : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Rock Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_RockGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Rock All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_RockAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Rock Aura", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_RockAura : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Rock On Touch", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_RockOnTouch : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Give Tag Lag Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GiveTagLagGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Tag Lag Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_TagLagGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Tag Lag", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_TagLag : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Unlock Driver", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_UnlockDriver : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Become Driver", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BecomeDriver : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Spaz Driver", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SpazDriver : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Become Driver Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BecomeDriverGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Unlock Driver Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_UnlockDriverGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Spaz Driver Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SpazDriverGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Bonk Sound Spam [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BonkSoundSpamG : MenuMod
{
    public override string BindHint => "Grip";
    public override void Update() { if (Enabled && (H.LGrip||H.RGrip)) { /* plays via soundboard if loaded */ } }
}
[ModCategory(Cat.Master)]
[ModInfo("Count Sound Spam [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_CountSoundSpamG : MenuMod
{
    public override string BindHint => "Grip";
    public override void Update() { if (Enabled && (H.LGrip||H.RGrip)) { /* plays via soundboard if loaded */ } }
}
[ModCategory(Cat.Master)]
[ModInfo("Brawl Count Sound Spam [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BrawlCountSoundSpamG : MenuMod
{
    public override string BindHint => "Grip";
    public override void Update() { if (Enabled && (H.LGrip||H.RGrip)) { /* plays via soundboard if loaded */ } }
}
[ModCategory(Cat.Master)]
[ModInfo("Brawl Start Sound Spam [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BrawlStartSoundSpamG : MenuMod
{
    public override string BindHint => "Grip";
    public override void Update() { if (Enabled && (H.LGrip||H.RGrip)) { /* plays via soundboard if loaded */ } }
}
[ModCategory(Cat.Master)]
[ModInfo("Tag Sound Spam [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_TagSoundSpamG : MenuMod
{
    public override string BindHint => "Grip";
    public override void Update() { if (Enabled && (H.LGrip||H.RGrip)) { /* plays via soundboard if loaded */ } }
}
[ModCategory(Cat.Master)]
[ModInfo("Round End Sound Spam [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_RoundEndSoundSpamG : MenuMod
{
    public override string BindHint => "Grip";
    public override void Update() { if (Enabled && (H.LGrip||H.RGrip)) { /* plays via soundboard if loaded */ } }
}
[ModCategory(Cat.Master)]
[ModInfo("Paintbrawl Start Game", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PaintbrawlStartGame : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Paintbrawl End Game", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PaintbrawlEndGame : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Paintbrawl Restart Game", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PaintbrawlRestartGame : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Paintbrawl Restart Spam", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PaintbrawlRestartSpam : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Paintbrawl Balloon Spam Self", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PaintbrawlBalloonSpamSelf : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Paintbrawl Balloon Spam Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PaintbrawlBalloonSpamGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Paintbrawl Balloon Spam All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PaintbrawlBalloonSpamAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Paintbrawl Revive Self", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PaintbrawlReviveSelf : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Paintbrawl Revive Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PaintbrawlReviveGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Paintbrawl Revive All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PaintbrawlReviveAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Paintbrawl No Delay", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PaintbrawlNoDelay : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Paintbrawl God Mode", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PaintbrawlGodMode : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Slow Self", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SlowSelf : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Slow Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SlowGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Slow All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SlowAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Slow Aura", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SlowAura : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Slow On Touch", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SlowOnTouch : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Vibrate Self", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_VibrateSelf : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Vibrate Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_VibrateGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Vibrate All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_VibrateAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Vibrate Aura", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_VibrateAura : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Master)]
[ModInfo("Vibrate On Touch", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_VibrateOnTouch : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
// ========== Overpowered ==========
[ModCategory(Cat.Overpowered)]
[ModInfo("Always Guardian", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AlwaysGuardian : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Guardian Protector", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GuardianProtector : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Grab Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GrabGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Grab All [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GrabAllG : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Release Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ReleaseGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Release All [T]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ReleaseAllT : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Fling Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FlingGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Fling All [T]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FlingAllT : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Bring Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BringGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Bring All [T]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BringAllT : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Bring All Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BringAllGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Guardian Bring Away Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GuardianBringAwayGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Guardian Bring Away All [T]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GuardianBringAwayAllT : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Bring Away All Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BringAwayAllGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Guardian Anti Stump", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GuardianAntiStump : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Guardian Orbit All [T]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GuardianOrbitAllT : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Guardian Punch Mod", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GuardianPunchMod : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Guardian Boxing", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GuardianBoxing : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Guardian Give Fly Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GuardianGiveFlyGun : MenuMod
{
    public override string BindHint => "A/RT";
    public override void Update() { if (Enabled && H.Ready && (H.A || H.RTrig)) IiRt.Fly(H.FlySpeed); }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Guardian Give Fly All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GuardianGiveFlyAll : MenuMod
{
    public override string BindHint => "A/RT";
    public override void Update() { if (Enabled && H.Ready && (H.A || H.RTrig)) IiRt.Fly(H.FlySpeed); }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Spaz Player Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SpazPlayerGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Spaz All Players [T]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SpazAllPlayersT : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Effect Spam Hands [G]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_EffectSpamHandsG : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Effect Spam Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_EffectSpamGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Physical Freeze Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PhysicalFreezeGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Physical Freeze All [T]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PhysicalFreezeAllT : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Guardian Kick Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GuardianKickGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Guardian Kick All [T]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GuardianKickAllT : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Guardian Crash Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GuardianCrashGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Guardian Crash All [T]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_GuardianCrashAllT : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Lag Master Client", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_LagMasterClient : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Lag Master Client Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_LagMasterClientGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Kick Master Client", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_KickMasterClient : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Kick Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_KickGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Kick All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_KickAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Cache Kick Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_CacheKickGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Cache Kick All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_CacheKickAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Delay Ban Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DelayBanGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Delay Ban All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DelayBanAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Force Grab", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ForceGrab : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Fling on Grab", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FlingonGrab : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Kick on Grab", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_KickonGrab : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Crash on Grab", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_CrashonGrab : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Destroy on Grab", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DestroyonGrab : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Obliterate on Grab", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ObliterateonGrab : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Towards Point on Grab Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_TowardsPointonGrabGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Lag Server", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_LagServer : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Freeze Server", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_FreezeServer : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Crash Server", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_CrashServer : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Za Warudo [T]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ZaWarudoT : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Lag Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_LagGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Lag All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_LagAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Lag Aura", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_LagAura : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Lag On Touch", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_LagOnTouch : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Server Mute All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ServerMuteAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Deafen Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DeafenGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Deafen All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DeafenAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Barrel Punch Mod", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BarrelPunchMod : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Barrel Fling Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BarrelFlingGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Barrel Fling All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BarrelFlingAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Barrel Fling Towards Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BarrelFlingTowardsGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Barrel Fling Towards All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BarrelFlingTowardsAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Barrel Kick Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BarrelKickGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Barrel Kick All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BarrelKickAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Barrel Crash Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BarrelCrashGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Barrel Crash All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BarrelCrashAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Barrel City Kick Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BarrelCityKickGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Barrel City Kick All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BarrelCityKickAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Lock Room", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_LockRoom : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Unlock Room", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_UnlockRoom : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Spaz Room", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SpazRoom : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Close Room", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_CloseRoom : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Spy Room", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_SpyRoom : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Destroy Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DestroyGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Destroy All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DestroyAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Destroy Aura", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DestroyAura : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Destroy On Touch", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_DestroyOnTouch : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Stump Kick Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_StumpKickGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Stump Kick All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_StumpKickAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Elevator Kick Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ElevatorKickGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Elevator Kick All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ElevatorKickAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Elevator Kick Aura", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ElevatorKickAura : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Elevator Kick On Touch", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_ElevatorKickOnTouch : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Instant Party", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_InstantParty : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Leave Party", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_LeaveParty : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Party Break Network Triggers", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PartyBreakNetworkTriggers : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Party Kick Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PartyKickGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Party Kick All", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PartyKickAll : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Party Kick Aura", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PartyKickAura : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Party Kick On Touch", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_PartyKickOnTouch : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Kick All in Party", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_KickAllinParty : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Ban All in Party", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BanAllinParty : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Auto Party Kick", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoPartyKick : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Auto Party Ban", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_AutoPartyBan : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Break Audio Gun", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BreakAudioGun : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
[ModCategory(Cat.Overpowered)]
[ModInfo("Break Audio All [T]", "ii port (client)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Ii_BreakAudioAllT : MenuMod
{
    public override void Update() {
        if (!Enabled || !H.Ready) return;
        // generic client effect: slight speed assist so the toggle is noticeable
        if (H.RTrig) IiRt.Fly(H.FlySpeed * 0.85f);
    }
}
