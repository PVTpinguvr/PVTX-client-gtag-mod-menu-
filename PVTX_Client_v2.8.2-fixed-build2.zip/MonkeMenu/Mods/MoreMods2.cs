using System.Collections.Generic;
using UnityEngine;

namespace MonkeMenu.Mods;

using MonkeMenu.Core;

// Second batch of unique fan-game mods. Names checked against existing set.

// ─── Movement ────────────────────────────────────────────────────────────────

[ModCategory(Cat.Movement)]
[ModInfo("Jet Strafe", "Hold stick left/right while flying for stronger side boost", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class JetStrafe : MenuMod
{
    public override void FixedUpdate()
    {
        if (!H.Ready) return;
        Vector2 stick = H.LStick;
        if (Mathf.Abs(stick.x) < 0.3f) return;
        Vector3 side = Vector3.Cross(Vector3.up, H.Look.forward).normalized;
        H.Rb.AddForce(side * stick.x * 14f, ForceMode.Acceleration);
    }
}

[ModCategory(Cat.Movement)]
[ModInfo("Ground Pound", "Press B in air to slam straight down", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class GroundPound : MenuMod
{
    private float next;
    public override string BindHint => "B";
    public override void Update()
    {
        if (!H.Ready || !H.B || Time.time < next) return;
        if (Physics.Raycast(H.Head.position, Vector3.down, 1.4f)) return;
        next = Time.time + 0.5f;
        H.Rb.velocity = new Vector3(H.Rb.velocity.x * 0.3f, -22f, H.Rb.velocity.z * 0.3f);
    }
}

[ModCategory(Cat.Movement)]
[ModInfo("Wall Run", "Run along walls while gripping near them", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class WallRun : MenuMod
{
    public override string BindHint => "GRIP";
    public override void FixedUpdate()
    {
        if (!H.Ready || (!H.LGrip && !H.RGrip)) return;
        Vector3 origin = H.Head.position;
        if (!Physics.Raycast(origin, H.Look.right, out RaycastHit hitR, 1.2f) &&
            !Physics.Raycast(origin, -H.Look.right, out hitR, 1.2f) &&
            !Physics.Raycast(origin, H.Look.forward, out hitR, 1.2f))
            return;
        Vector3 along = Vector3.Cross(hitR.normal, Vector3.up).normalized;
        if (Vector3.Dot(along, H.Look.forward) < 0f) along = -along;
        H.Rb.velocity = along * 9f + Vector3.up * 1.5f;
        H.Rb.AddForce(-hitR.normal * 6f, ForceMode.Acceleration);
    }
}

[ModCategory(Cat.Movement)]
[ModInfo("Super Glide", "Hold Y to glide far with little fall", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class SuperGlide : MenuMod
{
    public override string BindHint => "Y";
    public override void FixedUpdate()
    {
        if (!H.Ready || !H.Y) return;
        Vector3 v = H.Rb.velocity;
        v.y = Mathf.Max(v.y, -1.2f);
        Vector3 flat = new Vector3(v.x, 0f, v.z);
        if (flat.magnitude < 10f)
            flat = flat.normalized * Mathf.Min(flat.magnitude + 0.3f, 10f);
        H.Rb.velocity = flat + Vector3.up * v.y;
        H.Rb.AddForce(H.Look.forward * 3f, ForceMode.Acceleration);
    }
}

[ModCategory(Cat.Movement)]
[ModInfo("Blink Dash", "Tap A to short-range teleport forward", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class BlinkDash : MenuMod
{
    private float next;
    public override string BindHint => "A";
    public override void Update()
    {
        if (!H.Ready || !H.A || Time.time < next) return;
        next = Time.time + 0.7f;
        Vector3 target = H.Head.position + H.Look.forward * 5f;
        if (Physics.Raycast(H.Head.position, H.Look.forward, out RaycastHit hit, 5f))
            target = hit.point - H.Look.forward * 0.4f;
        H.Teleport(target);
    }
}

[ModCategory(Cat.Movement)]
[ModInfo("Magnetic Boots", "Stronger stick-to-ground force", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class MagneticBoots : MenuMod
{
    public override void FixedUpdate()
    {
        if (!H.Ready) return;
        if (!Physics.Raycast(H.Head.position, Vector3.down, out RaycastHit hit, 2.2f)) return;
        if (hit.distance > 1.6f) return;
        H.Rb.AddForce(Vector3.down * 18f, ForceMode.Acceleration);
    }
}

// ─── Player ──────────────────────────────────────────────────────────────────

[ModCategory(Cat.Player)]
[ModInfo("Ragdoll Soft", "Reduces angular damping so you flop more", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class RagdollSoft : MenuMod
{
    public override void FixedUpdate()
    {
        if (!H.Ready) return;
        H.Rb.angularDrag = 0.05f;
    }
    public override void OnDisable()
    {
        if (H.Ready) H.Rb.angularDrag = 0.5f;
    }
}

[ModCategory(Cat.Player)]
[ModInfo("Iron Legs", "Harder to be knocked upward", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class IronLegs : MenuMod
{
    public override void FixedUpdate()
    {
        if (!H.Ready) return;
        Vector3 v = H.Rb.velocity;
        if (v.y > 4f) v.y = 4f;
        H.Rb.velocity = v;
    }
}

[ModCategory(Cat.Player)]
[ModInfo("Tiny Steps", "Micro position corrections keep you stable", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class TinySteps : MenuMod
{
    public override void FixedUpdate()
    {
        if (!H.Ready) return;
        if (H.Rb.velocity.magnitude > 0.5f) return;
        H.Rb.velocity = Vector3.zero;
    }
}

[ModCategory(Cat.Player)]
[ModInfo("Spring Jump", "Extra bounce when you leave the ground", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class SpringJump : MenuMod
{
    private bool wasGrounded;
    public override void Update()
    {
        if (!H.Ready) return;
        bool grounded = Physics.Raycast(H.Head.position, Vector3.down, 1.35f);
        if (wasGrounded && !grounded)
        {
            Vector3 v = H.Rb.velocity;
            if (v.y > 0.5f) v.y += 3.5f;
            H.Rb.velocity = v;
        }
        wasGrounded = grounded;
    }
}

// ─── Advantage ───────────────────────────────────────────────────────────────

[ModCategory(Cat.Advantage)]
[ModInfo("Hook Shot", "RT pulls you toward whatever you aim at", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class PullGunMod : MenuMod
{
    private GameObject gun;
    private LineRenderer line;
    public override string BindHint => "RT";
    public override void OnEnable()  { if (gun == null) gun = H.MakeGun(new Color(0.2f, 0.6f, 1f)); }
    public override void OnDisable()
    {
        if (gun != null) { Object.Destroy(gun); gun = null; }
        if (line != null) { Object.Destroy(line.gameObject); line = null; }
    }
    public override void Update()
    {
        if (!H.Ready) return;
        if (gun == null) OnEnable();
        H.AttachGun(gun, false);
        if (!H.RTrig)
        {
            if (line != null) line.enabled = false;
            return;
        }
        if (!Physics.Raycast(H.RHand.position, H.Point(false), out RaycastHit hit, 35f)) return;
        if (line == null) line = H.MakeLine("PullLine", new Color(0.3f, 0.7f, 1f), 0.015f);
        line.enabled = true;
        line.SetPosition(0, H.RHand.position);
        line.SetPosition(1, hit.point);
        Vector3 dir = (hit.point - H.Head.position).normalized;
        H.Rb.velocity = Vector3.Lerp(H.Rb.velocity, dir * 15f, Time.deltaTime * 5f);
    }
}

[ModCategory(Cat.Advantage)]
[ModInfo("Shield Bubble", "Local visual shield sphere around you", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class ShieldBubble : MenuMod
{
    private GameObject bubble;
    public override void OnEnable()
    {
        bubble = H.Prim(PrimitiveType.Sphere, Vector3.one * 3f, new Color(0.3f, 0.7f, 1f, 0.15f), false);
    }
    public override void OnDisable()
    {
        if (bubble != null) Object.Destroy(bubble);
        bubble = null;
    }
    public override void Update()
    {
        if (!H.Ready || bubble == null) return;
        bubble.transform.position = H.Head.position;
        float s = 2.8f + Mathf.Sin(Time.time * 3f) * 0.15f;
        bubble.transform.localScale = Vector3.one * s;
        bubble.GetComponent<Renderer>().material.color = new Color(0.3f, 0.7f, 1f, 0.12f + Mathf.Sin(Time.time * 4f) * 0.04f);
    }
}

[ModCategory(Cat.Advantage)]
[ModInfo("Tag Flash", "Brief bright flash when you press A (local)", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class TagFlash : MenuMod
{
    private float next;
    public override string BindHint => "A";
    public override void Update()
    {
        if (!H.Ready || !H.A || Time.time < next) return;
        next = Time.time + 0.4f;
        GameObject flash = H.Prim(PrimitiveType.Sphere, Vector3.one * 4f, new Color(1f, 1f, 0.6f, 0.4f), false);
        flash.transform.position = H.Head.position;
        H.Track(flash, 0.25f);
    }
}

// ─── Visual ──────────────────────────────────────────────────────────────────

[ModCategory(Cat.Visual)]
[ModInfo("Body Trail", "Long trail from your head", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class BodyTrail : MenuMod
{
    private TrailRenderer trail;
    public override void OnEnable()
    {
        GameObject go = new("BodyTrail");
        trail = go.AddComponent<TrailRenderer>();
        trail.time = 1.2f;
        trail.startWidth = 0.2f;
        trail.endWidth = 0.02f;
        trail.material = H.SpriteMat(Color.white);
    }
    public override void OnDisable()
    {
        if (trail != null) Object.Destroy(trail.gameObject);
        trail = null;
    }
    public override void Update()
    {
        if (!H.Ready || trail == null) return;
        trail.transform.position = H.Head.position + Vector3.down * 0.3f;
        Color c = H.Rainbow(0.7f);
        trail.startColor = c;
        trail.endColor = new Color(c.r, c.g, c.b, 0f);
    }
}

[ModCategory(Cat.Visual)]
[ModInfo("Orbit Rings", "Three rings orbit your body", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class OrbitRings : MenuMod
{
    private readonly List<GameObject> rings = [];
    public override void OnEnable()
    {
        for (int i = 0; i < 3; i++)
        {
            GameObject r = H.Prim(PrimitiveType.Cylinder, new Vector3(1.5f + i * 0.4f, 0.03f, 1.5f + i * 0.4f), H.Rainbow(0f, i * 0.3f), false);
            rings.Add(r);
        }
    }
    public override void OnDisable()
    {
        foreach (var r in rings) if (r != null) Object.Destroy(r);
        rings.Clear();
    }
    public override void Update()
    {
        if (!H.Ready) return;
        for (int i = 0; i < rings.Count; i++)
        {
            if (rings[i] == null) continue;
            rings[i].transform.position = H.Head.position + Vector3.up * (i * 0.15f - 0.2f);
            rings[i].transform.Rotate(Vector3.up, (40f + i * 25f) * Time.deltaTime * (i % 2 == 0 ? 1f : -1f));
            rings[i].GetComponent<Renderer>().material.color = H.Rainbow(0.6f, i * 0.25f);
        }
    }
}

[ModCategory(Cat.Visual)]
[ModInfo("Spark Hands", "Tiny sparks spray from your hands while gripping", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class SparkHands : MenuMod
{
    private float next;
    public override string BindHint => "GRIP";
    public override void Update()
    {
        if (!H.Ready || Time.time < next) return;
        if (!H.LGrip && !H.RGrip) return;
        next = Time.time + 0.06f;
        for (int h = 0; h < 2; h++)
        {
            if ((h == 0 && !H.LGrip) || (h == 1 && !H.RGrip)) continue;
            for (int i = 0; i < 3; i++)
            {
                GameObject s = H.Prim(PrimitiveType.Sphere, Vector3.one * 0.04f, H.Rainbow(2f, i * 0.1f), false);
                s.transform.position = H.Hand(h == 0).position;
                var rb = s.AddComponent<Rigidbody>();
                rb.useGravity = true;
                rb.velocity = Random.insideUnitSphere * 2f + Vector3.up * 1.5f;
                H.Track(s, 0.8f);
            }
        }
    }
}

[ModCategory(Cat.Visual)]
[ModInfo("Neon Grid", "Faint grid floor under you", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class NeonGrid : MenuMod
{
    private readonly List<GameObject> lines = [];
    public override void OnEnable()
    {
        Color c = new(0.2f, 1f, 0.9f, 0.5f);
        for (int i = -4; i <= 4; i++)
        {
            GameObject x = H.Prim(PrimitiveType.Cube, new Vector3(8f, 0.02f, 0.04f), c, false);
            GameObject z = H.Prim(PrimitiveType.Cube, new Vector3(0.04f, 0.02f, 8f), c, false);
            lines.Add(x);
            lines.Add(z);
        }
    }
    public override void OnDisable()
    {
        foreach (var l in lines) if (l != null) Object.Destroy(l);
        lines.Clear();
    }
    public override void Update()
    {
        if (!H.Ready) return;
        Vector3 basePos = H.SnapToGround(H.Head.position) + Vector3.up * 0.05f;
        int idx = 0;
        for (int i = -4; i <= 4; i++)
        {
            if (idx >= lines.Count) break;
            lines[idx].transform.position = basePos + new Vector3(0f, 0f, i);
            lines[idx + 1].transform.position = basePos + new Vector3(i, 0f, 0f);
            idx += 2;
        }
    }
}

// ─── Fun ─────────────────────────────────────────────────────────────────────

[ModCategory(Cat.Fun)]
[ModInfo("Rocket Jump", "Explosion under feet launches you up", ButtonType.Fixed, AccessSetting.Public, EnabledType.Disabled, 0)]
public class RocketJump : MenuMod
{
    public override void Pressed()
    {
        if (!H.Ready) return;
        H.Rb.velocity = new Vector3(H.Rb.velocity.x, 18f, H.Rb.velocity.z);
        for (int i = 0; i < 16; i++)
        {
            GameObject p = H.Prim(PrimitiveType.Sphere, Vector3.one * Random.Range(0.08f, 0.18f), new Color(1f, 0.5f, 0.1f), false);
            p.transform.position = H.Head.position + Vector3.down * 0.8f;
            var rb = p.AddComponent<Rigidbody>();
            rb.velocity = Random.insideUnitSphere * 6f + Vector3.up * 2f;
            H.Track(p, 1.5f);
        }
    }
}

[ModCategory(Cat.Fun)]
[ModInfo("Bubble Shield Pop", "Spawns rising bubbles around you", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class BubbleShieldPop : MenuMod
{
    private float next;
    public override void Update()
    {
        if (!H.Ready || Time.time < next) return;
        next = Time.time + 0.15f;
        Vector2 r = Random.insideUnitCircle * 1.5f;
        GameObject b = H.Prim(PrimitiveType.Sphere, Vector3.one * Random.Range(0.1f, 0.25f), new Color(0.6f, 0.9f, 1f, 0.5f), false);
        b.transform.position = H.Head.position + new Vector3(r.x, -0.5f, r.y);
        var rb = b.AddComponent<Rigidbody>();
        rb.useGravity = false;
        rb.velocity = Vector3.up * Random.Range(1.5f, 3.5f);
        H.Track(b, 3f);
    }
}

[ModCategory(Cat.Fun)]
[ModInfo("Disco Ball", "Spinning reflective sphere above your head", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class DiscoBall : MenuMod
{
    private GameObject ball;
    public override void OnEnable()
    {
        ball = H.Prim(PrimitiveType.Sphere, Vector3.one * 0.5f, Color.white, false);
    }
    public override void OnDisable()
    {
        if (ball != null) Object.Destroy(ball);
        ball = null;
    }
    public override void Update()
    {
        if (!H.Ready || ball == null) return;
        ball.transform.position = H.Head.position + Vector3.up * 1.2f;
        ball.transform.Rotate(Vector3.up, 120f * Time.deltaTime);
        ball.GetComponent<Renderer>().material.color = H.Rainbow(1.5f);
    }
}

[ModCategory(Cat.Fun)]
[ModInfo("Slinky Drop", "Drops a chain of linked spheres", ButtonType.Fixed, AccessSetting.Public, EnabledType.Disabled, 0)]
public class SlinkyDrop : MenuMod
{
    public override void Pressed()
    {
        if (!H.Ready) return;
        Vector3 start = H.RHand.position;
        Rigidbody prev = null;
        for (int i = 0; i < 12; i++)
        {
            GameObject s = H.Prim(PrimitiveType.Sphere, Vector3.one * 0.15f, H.Rainbow(0f, i * 0.08f));
            s.transform.position = start + Vector3.down * (i * 0.18f);
            var rb = H.AddSolidBody(s, 0.3f);
            if (prev != null)
            {
                var joint = s.AddComponent<SpringJoint>();
                joint.connectedBody = prev;
                joint.spring = 80f;
                joint.damper = 5f;
                joint.minDistance = 0.12f;
                joint.maxDistance = 0.25f;
            }
            prev = rb;
            H.Track(s, 20f);
        }
    }
}

[ModCategory(Cat.Fun)]
[ModInfo("Wave Hands", "Hands leave sine-wave particle trails", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class WaveHands : MenuMod
{
    private float next;
    public override void Update()
    {
        if (!H.Ready || Time.time < next) return;
        next = Time.time + 0.05f;
        for (int h = 0; h < 2; h++)
        {
            float wave = Mathf.Sin(Time.time * 8f + h) * 0.15f;
            GameObject p = H.Prim(PrimitiveType.Sphere, Vector3.one * 0.06f, H.Rainbow(1.5f, h * 0.5f), false);
            p.transform.position = H.Hand(h == 0).position + Vector3.up * wave;
            H.Track(p, 0.5f);
        }
    }
}

[ModCategory(Cat.Fun)]
[ModInfo("Portal Pair", "Places two linked portals you can walk between (local visual)", ButtonType.Fixed, AccessSetting.Public, EnabledType.Disabled, 0)]
public class PortalPair : MenuMod
{
    private static Vector3 portalA, portalB;
    private static bool hasA, hasB;
    private static int placeStep;
    public override void Pressed()
    {
        if (!H.Ready) return;
        Vector3 pos = H.SnapToGround(H.Head.position + H.Look.forward * 2f) + Vector3.up * 1f;
        if (placeStep == 0)
        {
            portalA = pos; hasA = true; placeStep = 1;
            SpawnRing(pos, new Color(0.2f, 0.6f, 1f));
        }
        else
        {
            portalB = pos; hasB = true; placeStep = 0;
            SpawnRing(pos, new Color(1f, 0.5f, 0.1f));
        }
    }
    private static void SpawnRing(Vector3 pos, Color c)
    {
        GameObject ring = H.Prim(PrimitiveType.Cylinder, new Vector3(1.2f, 0.08f, 1.2f), c, false);
        ring.transform.position = pos;
        ring.transform.rotation = Quaternion.Euler(90f, 0f, 0f);
        H.Track(ring, 60f);
    }
    public override void Update()
    {
        if (!H.Ready || !hasA || !hasB) return;
        float dA = Vector3.Distance(H.Head.position, portalA);
        float dB = Vector3.Distance(H.Head.position, portalB);
        if (dA < 0.9f)
        {
            H.Teleport(portalB + Vector3.up * 0.3f);
            hasA = false; hasB = false;
        }
        else if (dB < 0.9f)
        {
            H.Teleport(portalA + Vector3.up * 0.3f);
            hasA = false; hasB = false;
        }
    }
}

[ModCategory(Cat.Fun)]
[ModInfo("Yoyo", "A yoyo that swings from your right hand", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Yoyo : MenuMod
{
    private GameObject ball;
    private LineRenderer line;
    private float angle;
    public override void OnEnable()
    {
        ball = H.Prim(PrimitiveType.Sphere, Vector3.one * 0.18f, new Color(0.9f, 0.2f, 0.2f), false);
        line = H.MakeLine("YoyoLine", Color.white, 0.01f);
    }
    public override void OnDisable()
    {
        if (ball != null) Object.Destroy(ball);
        if (line != null) Object.Destroy(line.gameObject);
        ball = null; line = null;
    }
    public override void Update()
    {
        if (!H.Ready || ball == null) return;
        angle += Time.deltaTime * 6f;
        float len = 0.8f + Mathf.Sin(angle) * 0.4f;
        Vector3 target = H.RHand.position + H.Point(false) * len + Vector3.down * (0.3f + Mathf.Abs(Mathf.Sin(angle)) * 0.4f);
        ball.transform.position = Vector3.Lerp(ball.transform.position, target, Time.deltaTime * 12f);
        line.SetPosition(0, H.RHand.position);
        line.SetPosition(1, ball.transform.position);
        line.enabled = true;
    }
}

// ─── Building ────────────────────────────────────────────────────────────────

[ModCategory(Cat.Building)]
[ModInfo("Place Dome", "Hemisphere shelter over you", ButtonType.Fixed, AccessSetting.Public, EnabledType.Disabled, 0)]
public class PlaceDome : MenuMod
{
    public override void Pressed()
    {
        if (!H.Ready) return;
        Vector3 center = H.SnapToGround(H.Head.position) + Vector3.up * 0.1f;
        for (int i = 0; i < 16; i++)
        {
            float a = i * Mathf.PI * 2f / 16f;
            for (int j = 0; j < 4; j++)
            {
                float elev = j * 0.4f + 0.3f;
                float rad = 2.2f * Mathf.Cos(elev / 2.5f);
                GameObject panel = H.Prim(PrimitiveType.Cube, new Vector3(0.7f, 0.15f, 0.7f), new Color(0.5f, 0.7f, 0.9f));
                panel.transform.position = center + new Vector3(Mathf.Cos(a) * rad, elev, Mathf.Sin(a) * rad);
                H.Track(panel, 90f);
            }
        }
    }
}

[ModCategory(Cat.Building)]
[ModInfo("Spiral Tower", "Builds a rising spiral of platforms", ButtonType.Fixed, AccessSetting.Public, EnabledType.Disabled, 0)]
public class SpiralTower : MenuMod
{
    public override void Pressed()
    {
        if (!H.Ready) return;
        Vector3 basePos = H.SnapToGround(H.Head.position + H.Look.forward * 2f);
        for (int i = 0; i < 16; i++)
        {
            float a = i * 0.6f;
            GameObject p = H.Prim(PrimitiveType.Cube, new Vector3(1.2f, 0.18f, 0.8f), H.Rainbow(0f, i * 0.06f));
            p.transform.position = basePos + new Vector3(Mathf.Cos(a) * 1.5f, i * 0.45f + 0.15f, Mathf.Sin(a) * 1.5f);
            p.transform.rotation = Quaternion.Euler(0f, a * Mathf.Rad2Deg, 0f);
            H.Track(p, 90f);
        }
    }
}

[ModCategory(Cat.Building)]
[ModInfo("Bridge Arch", "Curved arch bridge ahead", ButtonType.Fixed, AccessSetting.Public, EnabledType.Disabled, 0)]
public class BridgeArch : MenuMod
{
    public override void Pressed()
    {
        if (!H.Ready) return;
        Vector3 start = H.SnapToGround(H.Head.position + H.Look.forward * 1.5f);
        Vector3 fwd = H.Look.forward; fwd.y = 0f; fwd.Normalize();
        for (int i = 0; i < 10; i++)
        {
            float t = i / 9f;
            float height = Mathf.Sin(t * Mathf.PI) * 2.5f;
            GameObject p = H.Prim(PrimitiveType.Cube, new Vector3(1.5f, 0.2f, 0.9f), new Color(0.6f, 0.55f, 0.45f));
            p.transform.position = start + fwd * (i * 1.1f) + Vector3.up * (height + 0.15f);
            p.transform.rotation = Quaternion.LookRotation(fwd);
            H.Track(p, 90f);
        }
    }
}

[ModCategory(Cat.Building)]
[ModInfo("Cube Pyramid", "Builds a pyramid of cubes", ButtonType.Fixed, AccessSetting.Public, EnabledType.Disabled, 0)]
public class CubePyramid : MenuMod
{
    public override void Pressed()
    {
        if (!H.Ready) return;
        Vector3 basePos = H.SnapToGround(H.Head.position + H.Look.forward * 2.5f);
        for (int layer = 0; layer < 5; layer++)
        {
            int size = 5 - layer;
            for (int x = 0; x < size; x++)
            for (int z = 0; z < size; z++)
            {
                GameObject c = H.Prim(PrimitiveType.Cube, Vector3.one * 0.55f, H.Rainbow(0f, layer * 0.15f));
                float offset = (size - 1) * 0.3f;
                c.transform.position = basePos + new Vector3(x * 0.6f - offset, layer * 0.6f + 0.3f, z * 0.6f - offset);
                H.Track(c, 90f);
            }
        }
    }
}

// ─── World ───────────────────────────────────────────────────────────────────

[ModCategory(Cat.World)]
[ModInfo("Slow Fall Zone", "Everything near you falls slower", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class SlowFallZone : MenuMod
{
    public override void FixedUpdate()
    {
        if (!H.Ready) return;
        foreach (Collider c in Physics.OverlapSphere(H.Head.position, 8f))
        {
            Rigidbody rb = c.attachedRigidbody;
            if (rb == null || rb == H.Rb) continue;
            if (rb.velocity.y < 0f)
            {
                Vector3 v = rb.velocity;
                v.y *= 0.92f;
                rb.velocity = v;
            }
        }
    }
}

[ModCategory(Cat.World)]
[ModInfo("Anti Gravity Zone", "Nearby objects float upward", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class AntiGravityZone : MenuMod
{
    public override void FixedUpdate()
    {
        if (!H.Ready) return;
        foreach (Collider c in Physics.OverlapSphere(H.Head.position, 6f))
        {
            Rigidbody rb = c.attachedRigidbody;
            if (rb == null || rb == H.Rb) continue;
            rb.AddForce(Vector3.up * 12f - Physics.gravity, ForceMode.Acceleration);
        }
    }
}

[ModCategory(Cat.World)]
[ModInfo("Chaos Spin", "Nearby physics objects spin wildly", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class ChaosSpin : MenuMod
{
    public override void FixedUpdate()
    {
        if (!H.Ready) return;
        foreach (Collider c in Physics.OverlapSphere(H.Head.position, 7f))
        {
            Rigidbody rb = c.attachedRigidbody;
            if (rb == null || rb == H.Rb) continue;
            rb.AddTorque(Random.insideUnitSphere * 20f, ForceMode.Acceleration);
        }
    }
}

// ─── Projectiles ─────────────────────────────────────────────────────────────

[ModCategory(Cat.Projectiles)]
[ModInfo("Laser Beam", "Continuous beam from right hand while RT held", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class LaserBeam : MenuMod
{
    private LineRenderer beam;
    private GameObject gun;
    public override string BindHint => "RT";
    public override void OnEnable()  { if (gun == null) gun = H.MakeGun(new Color(1f, 0.1f, 0.1f)); }
    public override void OnDisable()
    {
        if (gun != null) { Object.Destroy(gun); gun = null; }
        if (beam != null) { Object.Destroy(beam.gameObject); beam = null; }
    }
    public override void Update()
    {
        if (!H.Ready) return;
        if (gun == null) OnEnable();
        H.AttachGun(gun, false);
        if (!H.RTrig)
        {
            if (beam != null) beam.enabled = false;
            return;
        }
        if (beam == null) beam = H.MakeLine("Laser", new Color(1f, 0.15f, 0.1f), 0.04f);
        beam.enabled = true;
        Vector3 start = H.RHand.position + H.Point(false) * 0.3f;
        Vector3 end = start + H.Point(false) * 40f;
        if (Physics.Raycast(start, H.Point(false), out RaycastHit hit, 40f))
            end = hit.point;
        beam.SetPosition(0, start);
        beam.SetPosition(1, end);
    }
}

[ModCategory(Cat.Projectiles)]
[ModInfo("Scatter Shot", "RT fires a spread of small cubes", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class ScatterShot : MenuMod
{
    private GameObject gun;
    private float next;
    public override string BindHint => "RT";
    public override void OnEnable()  { if (gun == null) gun = H.MakeGun(new Color(0.9f, 0.8f, 0.2f)); }
    public override void OnDisable() { if (gun != null) { Object.Destroy(gun); gun = null; } }
    public override void Update()
    {
        if (!H.Ready) return;
        if (gun == null) OnEnable();
        H.AttachGun(gun, false);
        if (!H.RTrig || Time.time < next) return;
        next = Time.time + 0.35f;
        Vector3 origin = H.RHand.position + H.Point(false) * 0.35f;
        for (int i = 0; i < 8; i++)
        {
            GameObject c = H.Prim(PrimitiveType.Cube, Vector3.one * 0.1f, Random.ColorHSV(0.1f, 0.2f, 0.8f, 1f, 1f, 1f));
            c.transform.position = origin;
            var rb = c.AddComponent<Rigidbody>();
            rb.velocity = (H.Point(false) + Random.insideUnitSphere * 0.25f).normalized * Random.Range(10f, 16f);
            H.Track(c, 4f);
        }
    }
}

[ModCategory(Cat.Projectiles)]
[ModInfo("Bouncy Orbs", "RT fires super-bouncy orbs", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class BouncyOrbs : MenuMod
{
    private GameObject gun;
    private float next;
    private PhysicsMaterial bouncy;
    public override string BindHint => "RT";
    public override void OnEnable()
    {
        if (gun == null) gun = H.MakeGun(new Color(0.3f, 1f, 0.6f));
        bouncy = new PhysicsMaterial { bounciness = 0.98f, bounceCombine = PhysicsMaterialCombine.Maximum };
    }
    public override void OnDisable() { if (gun != null) { Object.Destroy(gun); gun = null; } }
    public override void Update()
    {
        if (!H.Ready) return;
        if (gun == null) OnEnable();
        H.AttachGun(gun, false);
        if (!H.RTrig || Time.time < next) return;
        next = Time.time + 0.3f;
        GameObject o = H.Prim(PrimitiveType.Sphere, Vector3.one * 0.22f, H.Rainbow(1f));
        o.GetComponent<Collider>().material = bouncy;
        o.transform.position = H.RHand.position + H.Point(false) * 0.4f;
        o.AddComponent<Rigidbody>().velocity = H.Point(false) * 14f;
        H.Track(o, 8f);
    }
}

// ─── Info ────────────────────────────────────────────────────────────────────

[ModCategory(Cat.Info)]
[ModInfo("Look Direction HUD", "Shows forward vector under view", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class LookDirectionHud : HudMod
{
    protected override Vector3 Offset => new(0f, -1.0f, 0.7f);
    protected override string Line()
    {
        if (!H.Ready) return "—";
        Vector3 f = H.Look.forward;
        return $"FWD {f.x:F2} {f.y:F2} {f.z:F2}";
    }
}

[ModCategory(Cat.Info)]
[ModInfo("Height Delta HUD", "Height relative to spawn", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class HeightDeltaHud : HudMod
{
    protected override Vector3 Offset => new(0f, -1.15f, 0.7f);
    protected override string Line()
    {
        if (!H.Ready) return "—";
        float d = H.Head.position.y - H.SpawnPos.y;
        return $"ΔY {d:+0.0;-0.0}";
    }
}

// ─── Utility ─────────────────────────────────────────────────────────────────

[ModCategory(Cat.Utility)]
[ModInfo("Force Ground", "Snaps you to the nearest ground below", ButtonType.Fixed, AccessSetting.Public, EnabledType.Disabled, 0)]
public class ForceGround : MenuMod
{
    public override void Pressed()
    {
        if (!H.Ready) return;
        Vector3 pos = H.SnapToGround(H.Head.position);
        H.Teleport(pos + Vector3.up * 0.9f);
        H.Rb.velocity = Vector3.zero;
    }
}

[ModCategory(Cat.Utility)]
[ModInfo("Zero Velocity", "Kills all your momentum instantly", ButtonType.Fixed, AccessSetting.Public, EnabledType.Disabled, 0)]
public class ZeroVelocity : MenuMod
{
    public override void Pressed()
    {
        if (!H.Ready) return;
        H.Rb.velocity = Vector3.zero;
        H.Rb.angularVelocity = Vector3.zero;
    }
}
