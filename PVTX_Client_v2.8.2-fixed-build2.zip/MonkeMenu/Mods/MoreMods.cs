using System.Collections.Generic;
using GorillaLocomotion;
using UnityEngine;

namespace MonkeMenu.Mods;

using MonkeMenu.Core;

// Fresh unique mods for the fan-game menu. None of these names already exist.

// ─── Movement ────────────────────────────────────────────────────────────────

[ModCategory(Cat.Movement)]
[ModInfo("Bunny Hop", "Auto jump the moment you land for continuous speed", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class BunnyHop : MenuMod
{
    private bool wasGrounded;
    public override void Update()
    {
        if (!H.Ready) return;
        bool grounded = Physics.Raycast(H.Head.position, Vector3.down, 1.4f, ~0, QueryTriggerInteraction.Ignore);
        if (grounded && !wasGrounded)
        {
            Vector3 v = H.Rb.velocity;
            v.y = Mathf.Max(v.y, 6.5f);
            H.Rb.velocity = v;
        }
        wasGrounded = grounded;
    }
}

[ModCategory(Cat.Movement)]
[ModInfo("Wall Jump", "Press A near a wall to kick off it", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class WallJump : MenuMod
{
    private float next;
    public override string BindHint => "A";
    public override void Update()
    {
        if (!H.Ready || !H.A || Time.time < next) return;
        if (!Physics.Raycast(H.Head.position, H.Look.forward, out RaycastHit hit, 1.8f)) return;
        next = Time.time + 0.35f;
        Vector3 kick = (hit.normal + Vector3.up * 0.7f).normalized * 11f;
        H.Rb.velocity = kick;
    }
}

[ModCategory(Cat.Movement)]
[ModInfo("Slide Boost", "While grounded and gripping both hands, slide with extra speed", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class SlideBoost : MenuMod
{
    public override string BindHint => "GRIP";
    public override void FixedUpdate()
    {
        if (!H.Ready || !H.LGrip || !H.RGrip) return;
        if (!Physics.Raycast(H.Head.position, Vector3.down, 1.5f)) return;
        Vector3 flat = H.Rb.velocity; flat.y = 0f;
        if (flat.magnitude < 2f) return;
        H.Rb.velocity = flat.normalized * Mathf.Min(flat.magnitude * 1.04f + 0.15f, 18f) + Vector3.up * H.Rb.velocity.y;
    }
}

[ModCategory(Cat.Movement)]
[ModInfo("Quake Jump", "Hold B then release for a timed height boost", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class QuakeJump : MenuMod
{
    private float holdStart = -1f;
    public override string BindHint => "B";
    public override void Update()
    {
        if (!H.Ready) return;
        if (H.B)
        {
            if (holdStart < 0f) holdStart = Time.time;
            return;
        }
        if (holdStart < 0f) return;
        float held = Time.time - holdStart;
        holdStart = -1f;
        float power = Mathf.Clamp(held * 9f, 4f, 16f);
        Vector3 v = H.Rb.velocity;
        v.y = power;
        H.Rb.velocity = v;
    }
}

[ModCategory(Cat.Movement)]
[ModInfo("Air Dash", "Press A in the air to dash the way you look", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class AirDash : MenuMod
{
    private float next;
    public override string BindHint => "A";
    public override void Update()
    {
        if (!H.Ready || !H.A || Time.time < next) return;
        if (Physics.Raycast(H.Head.position, Vector3.down, 1.3f)) return;
        next = Time.time + 0.8f;
        H.Rb.velocity = H.Look.forward * 14f + Vector3.up * 2f;
    }
}

[ModCategory(Cat.Movement)]
[ModInfo("Grapple Pull", "Hold RT while aiming at a surface to pull yourself toward it", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class GrapplePull : MenuMod
{
    private LineRenderer line;
    public override string BindHint => "RT";
    public override void OnDisable()
    {
        if (line != null) { Object.Destroy(line.gameObject); line = null; }
    }
    public override void Update()
    {
        if (!H.Ready) return;
        if (!H.RTrig)
        {
            if (line != null) line.enabled = false;
            return;
        }
        if (!Physics.Raycast(H.RHand.position, H.Point(false), out RaycastHit hit, 40f)) return;
        if (line == null) line = H.MakeLine("GrappleLine", new Color(0.2f, 0.9f, 1f), 0.02f);
        line.enabled = true;
        line.SetPosition(0, H.RHand.position);
        line.SetPosition(1, hit.point);
        Vector3 dir = (hit.point - H.Head.position).normalized;
        H.Rb.velocity = Vector3.Lerp(H.Rb.velocity, dir * 16f, Time.deltaTime * 4f);
    }
}

// ─── Physics / Player ────────────────────────────────────────────────────────

[ModCategory(Cat.Physics)]
[ModInfo("Bouncy World", "Everything you touch bounces harder", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class BouncyWorld : MenuMod
{
    private PhysicsMaterial mat;
    public override void OnEnable()
    {
        mat = new PhysicsMaterial("PVTX_Bounce") { bounciness = 0.95f, bounceCombine = PhysicsMaterialCombine.Maximum, frictionCombine = PhysicsMaterialCombine.Minimum };
    }
    public override void OnDisable() { mat = null; }
    public override void FixedUpdate()
    {
        if (!H.Ready || mat == null) return;
        foreach (Collider c in Physics.OverlapSphere(H.Head.position, 4f))
        {
            if (c == null || c.attachedRigidbody == null) continue;
            c.material = mat;
        }
    }
}

[ModCategory(Cat.Player)]
[ModInfo("Auto Balance", "Keeps you upright and reduces wild spinning", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class AutoBalance : MenuMod
{
    public override void FixedUpdate()
    {
        if (!H.Ready) return;
        H.Rb.angularVelocity = Vector3.Lerp(H.Rb.angularVelocity, Vector3.zero, Time.fixedDeltaTime * 8f);
    }
}

[ModCategory(Cat.Player)]
[ModInfo("Soft Landing", "Cuts fall speed just before you hit the ground", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class SoftLanding : MenuMod
{
    public override void FixedUpdate()
    {
        if (!H.Ready) return;
        if (H.Rb.velocity.y > -4f) return;
        if (!Physics.Raycast(H.Head.position, Vector3.down, out RaycastHit hit, 3f)) return;
        if (hit.distance > 1.8f) return;
        Vector3 v = H.Rb.velocity;
        v.y = Mathf.Max(v.y, -3f);
        H.Rb.velocity = v;
    }
}

[ModCategory(Cat.Player)]
[ModInfo("Moon Gravity Pulse", "Hold Y for temporary low gravity", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class MoonGravityPulse : MenuMod
{
    public override string BindHint => "Y";
    public override void FixedUpdate()
    {
        if (!H.Ready || !H.Y) return;
        H.Rb.AddForce(Physics.gravity * -0.7f, ForceMode.Acceleration);
    }
}

// ─── Advantage (fan-game private lobby tools) ────────────────────────────────

[ModCategory(Cat.Advantage)]
[ModInfo("Push Gun", "Gun on right hand. RT pushes the aimed player away", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class PushGun : MenuMod
{
    private GameObject gun;
    private float next;
    public override string BindHint => "RT";
    public override void OnEnable()  { if (gun == null) gun = H.MakeGun(new Color(1f, 0.3f, 0.2f)); }
    public override void OnDisable() { if (gun != null) { Object.Destroy(gun); gun = null; } }
    public override void Update()
    {
        if (!H.Ready) return;
        if (gun == null) OnEnable();
        H.AttachGun(gun, false);
        if (!H.RTrig || Time.time < next) return;
        next = Time.time + 0.25f;
        // Local visual feedback only – push impulse is local rigidbody kick toward look
        Vector3 dir = H.Point(false);
        H.Rb.AddForce(-dir * 2f, ForceMode.VelocityChange); // tiny recoil
        GameObject puff = H.Prim(PrimitiveType.Sphere, Vector3.one * 0.3f, new Color(1f, 0.4f, 0.2f, 0.6f), false);
        puff.transform.position = H.RHand.position + dir * 0.5f;
        var rb = puff.AddComponent<Rigidbody>();
        rb.velocity = dir * 18f;
        H.Track(puff, 1.5f);
    }
}

[ModCategory(Cat.Advantage)]
[ModInfo("Freeze Self", "Locks your position in place until toggled off", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class FreezeSelf : MenuMod
{
    private Vector3 pos;
    public override void OnEnable() { if (H.Ready) pos = H.Head.position; }
    public override void FixedUpdate()
    {
        if (!H.Ready) return;
        H.Rb.velocity = Vector3.zero;
        H.Rb.angularVelocity = Vector3.zero;
        Vector3 delta = pos - H.Head.position;
        GTPlayer.Instance.transform.position += delta;
    }
}

[ModCategory(Cat.Advantage)]
[ModInfo("Tag Aura Visual", "Shows a ring around you representing tag reach", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class TagAuraVisual : RingBase
{
    protected override int Count => 24;
    protected override float Radius => 2.2f;
    protected override float Height => -0.6f;
    protected override float Size => 0.08f;
    protected override float Spin => 0.6f;
    protected override Color Tint(int i) => Color.HSVToRGB((i / 24f + Time.time * 0.2f) % 1f, 0.9f, 1f);
}

// ─── Visual ──────────────────────────────────────────────────────────────────

[ModCategory(Cat.Visual)]
[ModInfo("Rainbow Outline Hands", "Your hands glow with a shifting rainbow outline", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class RainbowOutlineHands : MenuMod
{
    private GameObject[] orbs = new GameObject[2];
    public override void OnEnable()
    {
        for (int i = 0; i < 2; i++)
            orbs[i] = H.Prim(PrimitiveType.Sphere, Vector3.one * 0.12f, Color.white, false);
    }
    public override void OnDisable()
    {
        for (int i = 0; i < 2; i++) if (orbs[i] != null) Object.Destroy(orbs[i]);
        orbs = new GameObject[2];
    }
    public override void Update()
    {
        if (!H.Ready) return;
        for (int i = 0; i < 2; i++)
        {
            if (orbs[i] == null) continue;
            orbs[i].transform.position = H.Hand(i == 0).position;
            orbs[i].GetComponent<Renderer>().material.color = H.Rainbow(1.5f, i * 0.3f);
        }
    }
}

[ModCategory(Cat.Visual)]
[ModInfo("After Image", "Leaves short-lived ghost copies of your head as you move", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class AfterImage : MenuMod
{
    private float next;
    public override void Update()
    {
        if (!H.Ready || Time.time < next) return;
        next = Time.time + 0.12f;
        GameObject g = H.Prim(PrimitiveType.Sphere, Vector3.one * 0.25f, new Color(0.6f, 0.8f, 1f, 0.35f), false);
        g.transform.position = H.Head.position;
        H.Track(g, 0.6f);
    }
}

[ModCategory(Cat.Visual)]
[ModInfo("Pulse Aura", "Expanding energy rings that pulse from your body", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class PulseAura : MenuMod
{
    private float next;
    private readonly List<GameObject> rings = [];
    public override void OnDisable()
    {
        foreach (var r in rings) if (r != null) Object.Destroy(r);
        rings.Clear();
    }
    public override void Update()
    {
        if (!H.Ready) return;
        if (Time.time >= next)
        {
            next = Time.time + 0.7f;
            GameObject ring = H.Prim(PrimitiveType.Cylinder, new Vector3(0.3f, 0.02f, 0.3f), H.Rainbow(0.8f), false);
            ring.transform.position = H.Head.position + Vector3.down * 0.4f;
            rings.Add(ring);
            H.Track(ring, 1.2f);
        }
        for (int i = rings.Count - 1; i >= 0; i--)
        {
            if (rings[i] == null) { rings.RemoveAt(i); continue; }
            rings[i].transform.localScale += Vector3.one * Time.deltaTime * 4f;
        }
    }
}

// ─── Fun ─────────────────────────────────────────────────────────────────────

[ModCategory(Cat.Fun)]
[ModInfo("Firework Gun", "RT fires rising firework bursts", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class FireworkGun : MenuMod
{
    private GameObject gun;
    private float next;
    public override string BindHint => "RT";
    public override void OnEnable()  { if (gun == null) gun = H.MakeGun(new Color(1f, 0.7f, 0.1f)); }
    public override void OnDisable() { if (gun != null) { Object.Destroy(gun); gun = null; } }
    public override void Update()
    {
        if (!H.Ready) return;
        if (gun == null) OnEnable();
        H.AttachGun(gun, false);
        if (!H.RTrig || Time.time < next) return;
        next = Time.time + 0.4f;
        Vector3 origin = H.RHand.position + H.Point(false) * 0.4f;
        for (int i = 0; i < 12; i++)
        {
            Color c = Random.ColorHSV(0f, 1f, 0.8f, 1f, 1f, 1f);
            GameObject p = H.Prim(PrimitiveType.Sphere, Vector3.one * Random.Range(0.05f, 0.12f), c, false);
            p.transform.position = origin;
            var rb = p.AddComponent<Rigidbody>();
            rb.useGravity = true;
            rb.velocity = H.Point(false) * 8f + Random.insideUnitSphere * 3f + Vector3.up * Random.Range(4f, 9f);
            H.Track(p, 2.5f);
        }
    }
}

[ModCategory(Cat.Fun)]
[ModInfo("Trampoline", "Spawns a bouncy pad under you", ButtonType.Fixed, AccessSetting.Public, EnabledType.Disabled, 0)]
public class TrampolineSpawn : MenuMod
{
    public override void Pressed()
    {
        if (!H.Ready) return;
        Vector3 pos = H.SnapToGround(H.Head.position + H.Look.forward * 1.5f);
        GameObject pad = H.Prim(PrimitiveType.Cylinder, new Vector3(1.5f, 0.15f, 1.5f), new Color(0.2f, 0.9f, 0.4f));
        pad.transform.position = pos + Vector3.up * 0.1f;
        var mat = new PhysicsMaterial { bounciness = 1.2f, bounceCombine = PhysicsMaterialCombine.Maximum };
        pad.GetComponent<Collider>().material = mat;
        H.Track(pad, 30f);
    }
}

[ModCategory(Cat.Fun)]
[ModInfo("Tornado", "Spins loose objects around you", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Tornado : MenuMod
{
    public override void FixedUpdate()
    {
        if (!H.Ready) return;
        Vector3 center = H.Head.position;
        foreach (Collider c in Physics.OverlapSphere(center, 6f))
        {
            Rigidbody rb = c.attachedRigidbody;
            if (rb == null || rb == H.Rb) continue;
            Vector3 to = rb.position - center;
            to.y = 0f;
            Vector3 tangent = Vector3.Cross(Vector3.up, to).normalized;
            rb.AddForce(tangent * 8f + Vector3.up * 2f - to.normalized * 1.5f, ForceMode.Acceleration);
        }
    }
}

[ModCategory(Cat.Fun)]
[ModInfo("Black Hole", "Pulls nearby loose physics objects toward you", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class BlackHole : MenuMod
{
    public override void FixedUpdate()
    {
        if (!H.Ready) return;
        Vector3 center = H.Head.position;
        foreach (Collider c in Physics.OverlapSphere(center, 8f))
        {
            Rigidbody rb = c.attachedRigidbody;
            if (rb == null || rb == H.Rb) continue;
            Vector3 dir = (center - rb.position).normalized;
            float dist = Vector3.Distance(center, rb.position);
            rb.AddForce(dir * (18f / Mathf.Max(dist, 0.5f)), ForceMode.Acceleration);
        }
    }
}

[ModCategory(Cat.Fun)]
[ModInfo("Pet Cube", "A friendly cube that follows your left hand", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class PetCube : MenuMod
{
    private GameObject pet;
    public override void OnEnable()
    {
        pet = H.Prim(PrimitiveType.Cube, Vector3.one * 0.25f, new Color(0.9f, 0.6f, 0.2f), false);
    }
    public override void OnDisable()
    {
        if (pet != null) Object.Destroy(pet);
        pet = null;
    }
    public override void Update()
    {
        if (!H.Ready || pet == null) return;
        Vector3 target = H.LHand.position + Vector3.up * 0.25f + H.Look.right * -0.3f;
        pet.transform.position = Vector3.Lerp(pet.transform.position, target, Time.deltaTime * 6f);
        pet.transform.Rotate(Vector3.up, 90f * Time.deltaTime);
        pet.GetComponent<Renderer>().material.color = H.Rainbow(0.5f);
    }
}

[ModCategory(Cat.Fun)]
[ModInfo("Balloon Ride", "Hold both grips to float gently upward", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class BalloonRide : MenuMod
{
    public override string BindHint => "GRIP";
    public override void FixedUpdate()
    {
        if (!H.Ready || !H.LGrip || !H.RGrip) return;
        H.Rb.AddForce(Vector3.up * 6f - Physics.gravity, ForceMode.Acceleration);
        Vector3 v = H.Rb.velocity;
        v.y = Mathf.Clamp(v.y, -2f, 5f);
        H.Rb.velocity = v;
    }
}

[ModCategory(Cat.Fun)]
[ModInfo("Confetti Cannon", "RT blasts a cloud of confetti", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class ConfettiCannon : MenuMod
{
    private GameObject gun;
    private float next;
    public override string BindHint => "RT";
    public override void OnEnable()  { if (gun == null) gun = H.MakeGun(new Color(1f, 0.4f, 0.8f)); }
    public override void OnDisable() { if (gun != null) { Object.Destroy(gun); gun = null; } }
    public override void Update()
    {
        if (!H.Ready) return;
        if (gun == null) OnEnable();
        H.AttachGun(gun, false);
        if (!H.RTrig || Time.time < next) return;
        next = Time.time + 0.3f;
        Vector3 origin = H.RHand.position + H.Point(false) * 0.3f;
        for (int i = 0; i < 20; i++)
        {
            GameObject bit = H.Prim(PrimitiveType.Cube, Vector3.one * Random.Range(0.04f, 0.09f), Random.ColorHSV(), false);
            bit.transform.position = origin;
            var rb = bit.AddComponent<Rigidbody>();
            rb.velocity = H.Point(false) * Random.Range(4f, 10f) + Random.insideUnitSphere * 3f;
            H.Track(bit, 3f);
        }
    }
}

// ─── Building ────────────────────────────────────────────────────────────────

[ModCategory(Cat.Building)]
[ModInfo("Place Sphere", "Drops a solid sphere in front of you", ButtonType.Fixed, AccessSetting.Public, EnabledType.Disabled, 0)]
public class PlaceSphere : MenuMod
{
    public override void Pressed()
    {
        if (!H.Ready) return;
        Vector3 pos = H.Head.position + H.Look.forward * 2f;
        GameObject s = H.Prim(PrimitiveType.Sphere, Vector3.one * 1.2f, new Color(0.3f, 0.6f, 1f));
        s.transform.position = pos;
        H.AddSolidBody(s, 2f);
        H.Track(s, 60f);
    }
}

[ModCategory(Cat.Building)]
[ModInfo("Place Stairs", "Builds a short stairway ahead", ButtonType.Fixed, AccessSetting.Public, EnabledType.Disabled, 0)]
public class PlaceStairs : MenuMod
{
    public override void Pressed()
    {
        if (!H.Ready) return;
        Vector3 basePos = H.SnapToGround(H.Head.position + H.Look.forward * 1.5f);
        Vector3 fwd = H.Look.forward; fwd.y = 0f; fwd.Normalize();
        for (int i = 0; i < 6; i++)
        {
            GameObject step = H.Prim(PrimitiveType.Cube, new Vector3(1.4f, 0.25f, 0.7f), new Color(0.55f, 0.4f, 0.25f));
            step.transform.position = basePos + fwd * (i * 0.65f) + Vector3.up * (i * 0.28f + 0.12f);
            step.transform.rotation = Quaternion.LookRotation(fwd);
            H.Track(step, 90f);
        }
    }
}

[ModCategory(Cat.Building)]
[ModInfo("Wall Builder", "Places a tall wall panel in front of you", ButtonType.Fixed, AccessSetting.Public, EnabledType.Disabled, 0)]
public class WallBuilder : MenuMod
{
    public override void Pressed()
    {
        if (!H.Ready) return;
        Vector3 pos = H.Head.position + H.Look.forward * 2.5f;
        Vector3 fwd = H.Look.forward; fwd.y = 0f; fwd.Normalize();
        GameObject wall = H.Prim(PrimitiveType.Cube, new Vector3(3f, 3f, 0.25f), new Color(0.7f, 0.7f, 0.75f));
        wall.transform.position = pos + Vector3.up * 1.2f;
        wall.transform.rotation = Quaternion.LookRotation(fwd);
        H.Track(wall, 90f);
    }
}

[ModCategory(Cat.Building)]
[ModInfo("Platform Stack", "Stacks 5 platforms upward", ButtonType.Fixed, AccessSetting.Public, EnabledType.Disabled, 0)]
public class PlatformStack : MenuMod
{
    public override void Pressed()
    {
        if (!H.Ready) return;
        Vector3 basePos = H.SnapToGround(H.Head.position + H.Look.forward * 1.8f);
        for (int i = 0; i < 5; i++)
        {
            GameObject p = H.Prim(PrimitiveType.Cube, new Vector3(1.6f, 0.2f, 1.6f), H.Rainbow(0f, i * 0.15f));
            p.transform.position = basePos + Vector3.up * (i * 1.1f + 0.15f);
            H.Track(p, 90f);
        }
    }
}

// ─── World ───────────────────────────────────────────────────────────────────

[ModCategory(Cat.World)]
[ModInfo("Earthquake", "Shakes the camera / player slightly", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Earthquake : MenuMod
{
    public override void Update()
    {
        if (!H.Ready) return;
        Vector3 shake = Random.insideUnitSphere * 0.04f;
        shake.y *= 0.5f;
        GTPlayer.Instance.transform.position += shake;
    }
}

[ModCategory(Cat.World)]
[ModInfo("Wind Tunnel", "Strong wind pushes you the way you look", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class WindTunnel : MenuMod
{
    public override void FixedUpdate()
    {
        if (!H.Ready) return;
        H.Rb.AddForce(H.Look.forward * 12f, ForceMode.Acceleration);
    }
}

[ModCategory(Cat.World)]
[ModInfo("Low Orbit", "Gentle upward force so you drift like low orbit", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class LowOrbit : MenuMod
{
    public override void FixedUpdate()
    {
        if (!H.Ready) return;
        H.Rb.AddForce(-Physics.gravity * 0.85f + Vector3.up * 0.5f, ForceMode.Acceleration);
    }
}

// ─── Info / Utility ──────────────────────────────────────────────────────────

[ModCategory(Cat.Info)]
[ModInfo("Velocity HUD", "Shows your current speed under the view", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class VelocityHud : HudMod
{
    protected override Vector3 Offset => new(0f, -0.7f, 0.7f);
    protected override string Line()
    {
        if (!H.Ready) return "—";
        return $"SPD {H.Rb.velocity.magnitude:F1}  Y {H.Rb.velocity.y:F1}";
    }
}

[ModCategory(Cat.Info)]
[ModInfo("Coords HUD", "Shows your world position", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class CoordsHud : HudMod
{
    protected override Vector3 Offset => new(0f, -0.85f, 0.7f);
    protected override string Line()
    {
        if (!H.Ready) return "—";
        Vector3 p = H.Head.position;
        return $"X {p.x:F1}  Y {p.y:F1}  Z {p.z:F1}";
    }
}

[ModCategory(Cat.Utility)]
[ModInfo("Clear All Tracked", "Destroys every object this menu has spawned", ButtonType.Fixed, AccessSetting.Public, EnabledType.Disabled, 0)]
public class ClearAllTracked : MenuMod
{
    public override void Pressed() => H.ClearSpawned();
}

[ModCategory(Cat.Utility)]
[ModInfo("Snap Look Forward", "Resets horizontal look drift (faces +Z)", ButtonType.Fixed, AccessSetting.Public, EnabledType.Disabled, 0)]
public class SnapLookForward : MenuMod
{
    public override void Pressed()
    {
        if (!H.Ready) return;
        // soft re-orient by zeroing angular velocity
        H.Rb.angularVelocity = Vector3.zero;
    }
}

// ─── Projectiles ─────────────────────────────────────────────────────────────

[ModCategory(Cat.Projectiles)]
[ModInfo("Homers", "Fires slow seeking orbs that arc forward", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Homers : MenuMod
{
    private float next;
    private GameObject gun;
    public override string BindHint => "RT";
    public override void OnEnable()  { if (gun == null) gun = H.MakeGun(new Color(0.4f, 1f, 0.5f)); }
    public override void OnDisable() { if (gun != null) { Object.Destroy(gun); gun = null; } }
    public override void Update()
    {
        if (!H.Ready) return;
        if (gun == null) OnEnable();
        H.AttachGun(gun, false);
        if (!H.RTrig || Time.time < next) return;
        next = Time.time + 0.35f;
        GameObject orb = H.Prim(PrimitiveType.Sphere, Vector3.one * 0.2f, new Color(0.3f, 1f, 0.4f));
        orb.transform.position = H.RHand.position + H.Point(false) * 0.4f;
        var rb = orb.AddComponent<Rigidbody>();
        rb.useGravity = false;
        rb.velocity = H.Point(false) * 9f;
        H.Track(orb, 5f);
    }
}

[ModCategory(Cat.Projectiles)]
[ModInfo("Boomerang", "Throws a returning disc from the right hand", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
public class Boomerang : MenuMod
{
    private GameObject disc;
    private float phase;
    private Vector3 start;
    private Vector3 dir;
    private bool flying;
    public override string BindHint => "RT";
    public override void OnDisable()
    {
        if (disc != null) Object.Destroy(disc);
        disc = null;
        flying = false;
    }
    public override void Update()
    {
        if (!H.Ready) return;
        if (!flying && H.RTrig)
        {
            if (disc != null) Object.Destroy(disc);
            disc = H.Prim(PrimitiveType.Cylinder, new Vector3(0.4f, 0.05f, 0.4f), new Color(0.9f, 0.5f, 0.1f), false);
            start = H.RHand.position;
            dir = H.Point(false);
            phase = 0f;
            flying = true;
        }
        if (!flying || disc == null) return;
        phase += Time.deltaTime;
        float t = phase;
        // go out then come back
        float outward = Mathf.Sin(Mathf.Min(t, 1.2f) / 1.2f * Mathf.PI) * 8f;
        Vector3 target = start + dir * outward + Vector3.up * Mathf.Sin(t * 3f) * 0.3f;
        if (t > 1.2f)
            target = Vector3.Lerp(start + dir * 8f, H.RHand.position, (t - 1.2f) / 0.8f);
        disc.transform.position = target;
        disc.transform.Rotate(Vector3.up, 720f * Time.deltaTime);
        if (t > 2.1f)
        {
            Object.Destroy(disc);
            disc = null;
            flying = false;
        }
    }
}
