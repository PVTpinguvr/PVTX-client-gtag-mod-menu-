# PVTX Client (MonkeMenu 2.8.1) (standalone BepInEx mod menu for a modded Gorilla Tag PC copy)

No hamburbur needed - this is its own plugin with its own menu.

## Quick way (Windows)
- Double click **install_menu.bat** - finds your game, checks BepInEx and .NET, builds, and installs the DLL.
- Double click **delete_menu.bat** - removes the DLL from the game.

## Build by hand
1. Install BepInEx 5 (x64) into your Gorilla Tag folder, launch the game once so it makes the BepInEx folders.
2. Install the .NET SDK (8+).
3. Set env var `GorillaTag_GamePath` to your game folder (or edit the fallback in MonkeMenu.csproj). Restart your terminal/IDE.
4. `dotnet build -c Release`  -> auto-copies MonkeMenu.dll to `<game>\BepInEx\plugins`.

## Use
- VR: press **X + Y together** to open/close the menu. It floats just above your **left hand** and follows it.
  Poke the buttons with the **ball on your right finger** - it lights up white while it touches a button, and
  the button fires the moment it touches (with a short click sound). Opening the menu plays a soft open chime. After each press there is a **0.2 second cooldown** so accidental
  double-pokes don't fire again. Swap hands in Utility > Menu Hand, resize the ball in Utility > Finger Ball.
- Every mod row shows a tag next to the name: controller binds like `[A]` / `[RT]` when the mod uses one, otherwise `[TOGGLE]`, `[+/-]`, or `[TAP]` by button type.
- Layout (like ii's Stupid Menu): title + FPS, then a `<` row and a `>` row that flip pages, then 7 rows.
  The home page lists **Enabled Mods** and every category. Inside one, the first row is **Back** and the rest are mods.
- `Name: value` mods have a small `<` on the left (previous value) and the big button (next value).
- The magnifier button under the bottom-right corner opens the on-menu keyboard (the first 4 matches stay clickable while you type).
- **Enabled Mods**: lists every mod that is on. Tap one to turn it off and it disappears from the list.
- Disconnect is in Utility (tap twice to confirm). Menu theme: Utility > Menu Theme (PVTX Purple is the default).
- Desktop/debug: press **Tab** for a window menu (has a search box too), **M** for the VR menu.
- Settings are remembered between launches. Utility > Reset Everything wipes them.

## Tabs
Movement, Physics, **World**, **Player**, **Advantage**, Visual, **Info**, Fun, Sound, Utility (+ Enabled Mods on the home page).
- **Movement** also has **Wall NoClip** (through walls, ground stays solid).
- **World** - No Collide Map / Blocks / Props (turn solid things into ghosts; turn the mod off and they come back), plus Freeze,
  Float, Hide, Magnet and Blast for loose physics objects. Also **Custom Leaderboard**, **Custom UPD Board**, and
  **Custom TOS Board** (overwrite lobby board text with fan-game friendly copy).
- **Player** - Air Jumps, Super Jump, Bouncy Monke, Anti Void, Snap To Ground, Rewind, Air Walk.
  (If you fall through the map with No Collide Map: Snap To Ground, Anti Void or Return To Spawn bring you back.)
- **Advantage** - Tag Gun, Tag Nearby, Invis, Ghost, Player ESP, No Tag, Long Arms, Size, Big Hitbox, Pull Gun, Flick Tag.
- **Info** - Top Speed / Distance / Stopwatch / Air Time / Battery / Session / Vertical Speed / Grounded / Frame Time read-outs.
- Utility has 3 preset slots (Preset / Save Preset / Load Preset), Disable Movement/World/Visual/Fun Mods, and Copy Room Name.
- The red **Disconnect** bar on top of the menu leaves the room (tap twice).

## Soundboard through the mic
Sound > **Sounds Through Mic** (on by default) sends every sound you play into voice chat by switching the game's voice
recorder from your microphone to the sound for as long as it plays. **Hear Sounds Locally** keeps it playing on your own
headset too, **Mic Mute** stops your real mic, and **Mic Hook** shows whether the voice recorder was found. Sound volume only
changes the local volume, not what's sent. If Mic Hook says "not found", look at BepInEx\LogOutput.log.

## Soundboard
Sounds play on your own machine. Built-in sounds are generated in code. To add your own, drop `.wav`, `.ogg` or `.mp3`
files into `<game>\BepInEx\MonkeMenuSounds` (Sound > Open Sounds Folder), then press **Reload Sounds**.

## Add your own mod
Add a class in `Mods/`:

    [ModCategory(Cat.Fun)]
    [ModInfo("My Mod", "What it does", ButtonType.Togglable, AccessSetting.Public, EnabledType.Disabled, 0)]
    public class MyMod : MenuMod
    {
        public override void OnEnable()  { }
        public override void OnDisable() { }
        public override void Update()    { }
    }

It's discovered automatically. All game API access is in `Mods/Helpers.cs` (class `H`).
Use `H.Look` (not `H.Head`) for "the way I'm looking". Button types: `Fixed` (press), `Togglable`, `Incremental` (`Name: value`).
